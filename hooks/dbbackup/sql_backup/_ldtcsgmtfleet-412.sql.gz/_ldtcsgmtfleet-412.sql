-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: ldtcsgmtfleet
-- ------------------------------------------------------
-- Server version 	5.7.17-log
-- Date: Thu, 19 Mar 2020 12:59:12 +0200

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ldtcsgmtfleet`
--

/*!40000 DROP DATABASE IF EXISTS `ldtcsgmtfleet`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ldtcsgmtfleet` /*!40100 DEFAULT CHARACTER SET utf8  COLLATE utf8_general_ci */;

USE `ldtcsgmtfleet`;

--
-- Table structure for table `accident_type`
--

DROP TABLE IF EXISTS `accident_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accident_type` (
  `accident_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `accident_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`accident_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accident_type`
--

LOCK TABLES `accident_type` WRITE;
/*!40000 ALTER TABLE `accident_type` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `accident_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `accident_type` with 0 row(s)
--

--
-- Table structure for table `accidents`
--

DROP TABLE IF EXISTS `accidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accidents` (
  `accident_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_registration_number` int(6) NOT NULL,
  `closing_km` int(11) NOT NULL,
  `drivers_surname` int(11) NOT NULL,
  `drivers_contact_details` int(11) DEFAULT NULL,
  `dealer_name` int(11) DEFAULT NULL,
  `model_of_vehicle` varchar(45) DEFAULT NULL,
  `date_of_accident` date DEFAULT NULL,
  `z181_accident_form` varchar(40) DEFAULT NULL,
  `z181_accident_form_uploaded` varchar(40) DEFAULT NULL,
  `copy_of_trip_authority` varchar(40) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  `road_or_street` varchar(40) DEFAULT NULL,
  `coordinates` varchar(40) DEFAULT NULL,
  `deaths` varchar(40) DEFAULT NULL,
  `fatal_amount` varchar(40) DEFAULT NULL,
  `injured` varchar(40) DEFAULT NULL,
  `injured_amount` varchar(40) DEFAULT NULL,
  `description_of_accident` text,
  `insured` varchar(40) DEFAULT NULL,
  `upload_photos_damaged_vehicle` varchar(40) DEFAULT NULL,
  `copy_of_sketch_plan` varchar(40) DEFAULT NULL,
  `accident_report_driver` varchar(40) DEFAULT NULL,
  `accident_report_supervisior` varchar(40) DEFAULT NULL,
  `claims_report_accident_committee` varchar(40) DEFAULT NULL,
  `insurance_claims_report` varchar(40) DEFAULT NULL,
  `amount_paid` varchar(40) DEFAULT NULL,
  `police_officer` varchar(40) DEFAULT NULL,
  `contact_details` varchar(40) DEFAULT NULL,
  `case_number` varchar(40) DEFAULT 'CAS_',
  `police_report` varchar(40) DEFAULT NULL,
  `accident_report_number` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`accident_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `closing_km` (`closing_km`),
  KEY `drivers_surname` (`drivers_surname`),
  KEY `dealer_name` (`dealer_name`),
  KEY `district` (`district`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accidents`
--

LOCK TABLES `accidents` WRITE;
/*!40000 ALTER TABLE `accidents` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `accidents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `accidents` with 0 row(s)
--

--
-- Table structure for table `application_status`
--

DROP TABLE IF EXISTS `application_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_status` (
  `application_id` int(11) NOT NULL AUTO_INCREMENT,
  `application_status` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_status`
--

LOCK TABLES `application_status` WRITE;
/*!40000 ALTER TABLE `application_status` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `application_status` VALUES (1,'Active'),(2,'Withdrawn'),(3,'Dormant'),(4,'Stolen'),(5,'Auction');
/*!40000 ALTER TABLE `application_status` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `application_status` with 5 row(s)
--

--
-- Table structure for table `auditor`
--

DROP TABLE IF EXISTS `auditor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditor` (
  `auditor_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `res_id` int(5) unsigned DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `ipaddr` varchar(25) DEFAULT NULL,
  `time_stmp` timestamp NULL DEFAULT NULL,
  `change_type` varchar(10) DEFAULT NULL,
  `table_name` varchar(40) DEFAULT NULL,
  `fieldName` varchar(40) DEFAULT NULL,
  `OldValue` text,
  `NewValue` text,
  PRIMARY KEY (`auditor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditor`
--

LOCK TABLES `auditor` WRITE;
/*!40000 ALTER TABLE `auditor` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `auditor` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `auditor` with 0 row(s)
--

--
-- Table structure for table `authorizations`
--

DROP TABLE IF EXISTS `authorizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authorizations` (
  `authorize_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_code` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  `job_status_date` date DEFAULT '0000-00-00',
  `job_status_age` varchar(40) DEFAULT NULL,
  `job_age` varchar(40) DEFAULT NULL,
  `job_category` int(11) DEFAULT NULL,
  `job_odometer` int(11) DEFAULT NULL,
  `instruction_note` int(11) DEFAULT NULL,
  `pre_authorisation_date` int(11) DEFAULT '1',
  `authorisation_date` date DEFAULT '0000-00-00',
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(6) DEFAULT NULL,
  `client` int(11) DEFAULT NULL,
  `province_name` int(11) DEFAULT NULL,
  `merchant_code` int(11) DEFAULT NULL,
  `merchant_name` int(11) DEFAULT NULL,
  `merchant_contact_email` int(11) DEFAULT NULL,
  `merchant_street_address` int(11) DEFAULT NULL,
  `merchant_suburb` int(11) DEFAULT NULL,
  `merchant_city` int(11) DEFAULT NULL,
  `merchant_address_code` int(11) DEFAULT NULL,
  `merchant_contact_details` int(11) DEFAULT NULL,
  `total_claim` int(11) DEFAULT NULL,
  `total_authorised` int(11) DEFAULT NULL,
  `authorization_number` int(11) DEFAULT NULL,
  `last_fuel_transaction_date` date DEFAULT '0000-00-00',
  `external_repairs` text,
  `repairs` varchar(40) DEFAULT NULL,
  `field28` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`authorize_id`),
  KEY `job_code` (`job_code`),
  KEY `job_status` (`job_status`),
  KEY `job_category` (`job_category`),
  KEY `job_odometer` (`job_odometer`),
  KEY `pre_authorisation_date` (`pre_authorisation_date`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `client` (`client`),
  KEY `province_name` (`province_name`),
  KEY `merchant_code` (`merchant_code`),
  KEY `total_claim` (`total_claim`),
  KEY `total_authorised` (`total_authorised`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authorizations`
--

LOCK TABLES `authorizations` WRITE;
/*!40000 ALTER TABLE `authorizations` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `authorizations` VALUES (1,1,2,'2017-12-05','78','84',3,1,1,1,'2018-01-09',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,'2018-01-16',NULL,NULL,NULL);
/*!40000 ALTER TABLE `authorizations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `authorizations` with 1 row(s)
--

--
-- Table structure for table `billing`
--

DROP TABLE IF EXISTS `billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing` (
  `billing_id` int(11) NOT NULL AUTO_INCREMENT,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `job_card_number` varchar(40) DEFAULT NULL,
  `maintenance_file` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  PRIMARY KEY (`billing_id`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing`
--

LOCK TABLES `billing` WRITE;
/*!40000 ALTER TABLE `billing` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `billing` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `billing` with 0 row(s)
--

--
-- Table structure for table `body_type`
--

DROP TABLE IF EXISTS `body_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `body_type` (
  `body_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_vehicle` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`body_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `body_type`
--

LOCK TABLES `body_type` WRITE;
/*!40000 ALTER TABLE `body_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `body_type` VALUES (1,'Coupe'),(2,'Cabriolet'),(3,'Sedan'),(4,'Hatchback'),(5,'Station Wagon'),(6,'Sport Utility Vehicle'),(7,'Sport Activity Vehicle'),(8,'Minibus'),(9,'Panel Van'),(10,'Drop Side'),(11,'Pick Up'),(12,'Multi Purpose Vehicle'),(13,'Chassis Cab'),(14,'Trailer'),(15,'Road Maintenance Equipment');
/*!40000 ALTER TABLE `body_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `body_type` with 15 row(s)
--

--
-- Table structure for table `breakdown_services`
--

DROP TABLE IF EXISTS `breakdown_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `breakdown_services` (
  `breakdown_id` int(11) NOT NULL AUTO_INCREMENT,
  `breakdown_during_office_hours` varchar(40) DEFAULT NULL,
  `breakdown_within_the_province` int(11) DEFAULT NULL,
  `breakdown_outside_the_province` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `breakdown_of_vehicle` varchar(40) DEFAULT NULL,
  `breakdown_within_or_outside_the_province` varchar(40) DEFAULT NULL,
  `description_of_vehicle_breakdown_notes` text,
  `description_of_vehicle_breakdown` varchar(40) DEFAULT NULL,
  `date_of_vehicle_breakdown` date DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `date_of_vehicle_reactivation` date DEFAULT NULL,
  `type_of_expenditure` varchar(40) DEFAULT NULL,
  `labour_category` varchar(40) DEFAULT NULL,
  `part_number` int(11) DEFAULT NULL,
  `part_name` int(11) DEFAULT NULL,
  `part_manufacturer_name` int(11) DEFAULT NULL,
  `quantity` varchar(40) DEFAULT NULL,
  `expense_of_item` decimal(10,2) DEFAULT '0.00',
  `labour_category_1` varchar(40) DEFAULT NULL,
  `part_number_1` int(11) DEFAULT NULL,
  `part_name_1` int(11) DEFAULT NULL,
  `part_manufacturer_name_1` int(11) DEFAULT NULL,
  `quantity_1` varchar(40) DEFAULT NULL,
  `expense_of_item_1` decimal(10,2) DEFAULT '0.00',
  `material_cost` decimal(10,2) DEFAULT '0.00',
  `average_worktime_hrs` varchar(40) DEFAULT NULL,
  `standard_labour_cost_per_hour` decimal(10,2) DEFAULT '0.00',
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `vat` decimal(10,2) DEFAULT '0.15',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `work_order_id` int(11) DEFAULT NULL,
  `work_order_status` varchar(40) DEFAULT NULL,
  `comments` longtext,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `receptionist` int(11) DEFAULT NULL,
  `receptionist_contact_email` int(11) DEFAULT NULL,
  `date_captured` datetime DEFAULT NULL,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`breakdown_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `job_card_number` (`job_card_number`),
  KEY `closing_km` (`closing_km`),
  KEY `part_number` (`part_number`),
  KEY `part_manufacturer_name` (`part_manufacturer_name`),
  KEY `part_number_1` (`part_number_1`),
  KEY `part_manufacturer_name_1` (`part_manufacturer_name_1`),
  KEY `workshop_name` (`workshop_name`),
  KEY `work_order_id` (`work_order_id`),
  KEY `part_name` (`part_name`),
  KEY `part_name_1` (`part_name_1`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `breakdown_services`
--

LOCK TABLES `breakdown_services` WRITE;
/*!40000 ALTER TABLE `breakdown_services` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `breakdown_services` VALUES (1,'Yes',NULL,NULL,1,1,NULL,'Yes','Within the Province','<br>',NULL,'2020-02-21',1,1,'2020-02-28','Material','Change::Replace',1,1,5,'1',375.98,'Change::Replace',NULL,NULL,NULL,NULL,0.00,45.89,'2',250.00,NULL,0.15,NULL,1,NULL,'Processing','<br>',NULL,1,1,'2020-02-28 00:00:00',NULL);
/*!40000 ALTER TABLE `breakdown_services` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `breakdown_services` with 1 row(s)
--

--
-- Table structure for table `breakdowns`
--

DROP TABLE IF EXISTS `breakdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `breakdowns` (
  `breakdown_id` int(11) NOT NULL AUTO_INCREMENT,
  `breakdown_of_vehicle` varchar(40) DEFAULT NULL,
  `description_of_vehicle_breakdown_notes` text,
  `description_of_vehicle_breakdown` varchar(40) DEFAULT NULL,
  `date_of_vehicle_breakdown` date DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `engine_number` int(6) DEFAULT NULL,
  `closing_km` int(11) NOT NULL,
  `date_of_vehicle_reactivation` date DEFAULT NULL,
  `type_of_expenditure` varchar(40) DEFAULT NULL,
  `labour_category` varchar(40) DEFAULT NULL,
  `part_number` int(11) DEFAULT NULL,
  `part_name` int(11) DEFAULT NULL,
  `part_manufacturer_name` int(11) DEFAULT NULL,
  `quantity` varchar(40) DEFAULT NULL,
  `expense_of_item` decimal(10,2) DEFAULT '0.00',
  `labour_category_1` varchar(40) DEFAULT NULL,
  `part_number_1` int(11) DEFAULT NULL,
  `part_name_1` int(11) DEFAULT NULL,
  `part_manufacturer_name_1` int(11) DEFAULT NULL,
  `quantity_1` varchar(40) DEFAULT NULL,
  `expense_of_item_1` decimal(10,2) DEFAULT '0.00',
  `material_cost` decimal(10,2) DEFAULT '0.00',
  `average_worktime_hrs` varchar(40) DEFAULT NULL,
  `standard_labour_cost_per_hour` decimal(10,2) DEFAULT '0.00',
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `vat` decimal(10,2) DEFAULT '0.15',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `work_order_id` int(11) DEFAULT NULL,
  `work_order_status` varchar(40) DEFAULT NULL,
  `comments` longtext,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `date_captured` date DEFAULT NULL,
  `receptionist` int(11) DEFAULT NULL,
  `receptionist_contact_email` int(11) DEFAULT NULL,
  `breakdown_during_office_hours` int(11) DEFAULT NULL,
  `breakdown_within_or_outside_the_province` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`breakdown_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `closing_km` (`closing_km`),
  KEY `part_number` (`part_number`),
  KEY `part_name` (`part_name`),
  KEY `part_manufacturer_name` (`part_manufacturer_name`),
  KEY `part_number_1` (`part_number_1`),
  KEY `part_name_1` (`part_name_1`),
  KEY `part_manufacturer_name_1` (`part_manufacturer_name_1`),
  KEY `workshop_name` (`workshop_name`),
  KEY `work_order_id` (`work_order_id`),
  KEY `job_card_number` (`job_card_number`),
  KEY `receptionist` (`receptionist`),
  KEY `receptionist_contact_email` (`receptionist_contact_email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `breakdowns`
--

LOCK TABLES `breakdowns` WRITE;
/*!40000 ALTER TABLE `breakdowns` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `breakdowns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `breakdowns` with 0 row(s)
--

--
-- Table structure for table `claim`
--

DROP TABLE IF EXISTS `claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claim` (
  `claim_id` int(11) NOT NULL AUTO_INCREMENT,
  `claim_code` varchar(40) DEFAULT NULL,
  `claim_status` int(11) DEFAULT NULL,
  `claim_category` int(11) DEFAULT NULL,
  `cost_centre` int(11) DEFAULT NULL,
  `client_identification` varchar(40) DEFAULT NULL,
  `department_name` int(11) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  `province` int(11) DEFAULT NULL,
  `merchant_name` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `pre_authorization_date` date DEFAULT '0000-00-00',
  `instruction_note` text,
  `invoice_date` date DEFAULT '0000-00-00',
  `upload_invoice` varchar(40) DEFAULT NULL,
  `payment_date` date DEFAULT '0000-00-00',
  `authorization_number` varchar(40) NOT NULL,
  `clearance_number` varchar(40) DEFAULT NULL,
  `vehicle_collected_date` date DEFAULT '0000-00-00',
  `total_claimed` decimal(10,2) DEFAULT '0.00',
  `total_authorized` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`claim_id`),
  KEY `claim_status` (`claim_status`),
  KEY `claim_category` (`claim_category`),
  KEY `cost_centre` (`cost_centre`),
  KEY `department_name` (`department_name`),
  KEY `district` (`district`),
  KEY `province` (`province`),
  KEY `merchant_name` (`merchant_name`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `closing_km` (`closing_km`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claim`
--

LOCK TABLES `claim` WRITE;
/*!40000 ALTER TABLE `claim` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `claim` VALUES (1,'LDTCS CD 2020 Sed-1',4,1,1,'Frans DeBussy',9,5,1,1,1,1,'2020-02-17','Repair the gearbox<br>','2020-02-18',NULL,'2020-02-28','LDTCS CD 2020 Sed-1/Feb','LDTCS CD 7890/March','2020-02-28',9651.56,9500.00);
/*!40000 ALTER TABLE `claim` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `claim` with 1 row(s)
--

--
-- Table structure for table `claim_category`
--

DROP TABLE IF EXISTS `claim_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claim_category` (
  `claim_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `claim_category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`claim_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claim_category`
--

LOCK TABLES `claim_category` WRITE;
/*!40000 ALTER TABLE `claim_category` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `claim_category` VALUES (1,'Maintenance and Repair'),(2,'Accident - minor'),(3,'General - minor'),(4,'Accident - major'),(5,'General - major');
/*!40000 ALTER TABLE `claim_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `claim_category` with 5 row(s)
--

--
-- Table structure for table `claim_status`
--

DROP TABLE IF EXISTS `claim_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claim_status` (
  `claim_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `claim_status` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`claim_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claim_status`
--

LOCK TABLES `claim_status` WRITE;
/*!40000 ALTER TABLE `claim_status` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `claim_status` VALUES (1,'Pending'),(2,'In Process'),(3,'Closed'),(4,'Started');
/*!40000 ALTER TABLE `claim_status` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `claim_status` with 4 row(s)
--

--
-- Table structure for table `collection_of_repaired_vehicles`
--

DROP TABLE IF EXISTS `collection_of_repaired_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_of_repaired_vehicles` (
  `collection_id` int(11) NOT NULL AUTO_INCREMENT,
  `reception_name_and_surname` varchar(40) DEFAULT NULL,
  `reception_persal_number` varchar(40) DEFAULT NULL,
  `reception_contact_details` varchar(40) DEFAULT NULL,
  `reception_email_address` varchar(40) DEFAULT NULL,
  `reception_signature` varchar(40) DEFAULT NULL,
  `driver_name_and_surname` varchar(40) DEFAULT NULL,
  `driver_persal_number` varchar(40) DEFAULT NULL,
  `driver_contacts_details` varchar(40) DEFAULT NULL,
  `driver_email_address` varchar(40) DEFAULT NULL,
  `driver_license_upload` varchar(40) DEFAULT NULL,
  `driver_signature` varchar(40) DEFAULT NULL,
  `government_garage_name` varchar(40) DEFAULT NULL,
  `government_garage_contact_details` varchar(40) DEFAULT NULL,
  `government_garage_address` text,
  `government_garage_email_address` varchar(40) DEFAULT NULL,
  `vehicle_inspection` varchar(40) DEFAULT NULL,
  `vehicle_interiour_condition` text,
  `vehicle_exteriour_condition` text,
  `vehicle_tyre_check` varchar(40) DEFAULT NULL,
  `sign_off_time` timestamp NULL DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `date_of_repaired_vehicle_collection` datetime DEFAULT NULL,
  `vehicle_inspection_form` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`collection_id`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `engine_number` (`engine_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_of_repaired_vehicles`
--

LOCK TABLES `collection_of_repaired_vehicles` WRITE;
/*!40000 ALTER TABLE `collection_of_repaired_vehicles` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `collection_of_repaired_vehicles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `collection_of_repaired_vehicles` with 0 row(s)
--

--
-- Table structure for table `cost_centre`
--

DROP TABLE IF EXISTS `cost_centre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_centre` (
  `cost_centre_id` int(11) NOT NULL AUTO_INCREMENT,
  `cost_centre` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`cost_centre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cost_centre`
--

LOCK TABLES `cost_centre` WRITE;
/*!40000 ALTER TABLE `cost_centre` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `cost_centre` VALUES (1,'Capricorn Cost Centre');
/*!40000 ALTER TABLE `cost_centre` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `cost_centre` with 1 row(s)
--

--
-- Table structure for table `costing`
--

DROP TABLE IF EXISTS `costing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `costing` (
  `costing_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_card_number` varchar(40) DEFAULT NULL,
  `spares_orders_qoutation` varchar(40) DEFAULT NULL,
  `labour_qoutation` varchar(40) DEFAULT NULL,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  PRIMARY KEY (`costing_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `costing`
--

LOCK TABLES `costing` WRITE;
/*!40000 ALTER TABLE `costing` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `costing` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `costing` with 0 row(s)
--

--
-- Table structure for table `dealer`
--

DROP TABLE IF EXISTS `dealer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealer` (
  `dealer_id` int(11) NOT NULL AUTO_INCREMENT,
  `dealer_type` int(11) DEFAULT NULL,
  `dealer_name` varchar(40) DEFAULT NULL,
  `contact_person` varchar(40) DEFAULT NULL,
  `contact_details` varchar(40) DEFAULT NULL,
  `contact_email` varchar(40) DEFAULT NULL,
  `make_of_vehicle` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`dealer_id`),
  KEY `dealer_type` (`dealer_type`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dealer`
--

LOCK TABLES `dealer` WRITE;
/*!40000 ALTER TABLE `dealer` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `dealer` VALUES (1,1,'Toyota',NULL,NULL,NULL,'Toyota'),(2,1,'Volkswagen',NULL,NULL,NULL,'Volkswagen'),(3,1,'Nissan',NULL,NULL,NULL,'Nissan'),(4,1,'Ford',NULL,NULL,NULL,'Ford'),(5,1,'Isuzu',NULL,NULL,NULL,'Isuzu'),(6,1,'Mercedes Benz',NULL,NULL,NULL,'Mercedes Benz'),(7,1,'BMW',NULL,NULL,NULL,'BMW');
/*!40000 ALTER TABLE `dealer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `dealer` with 7 row(s)
--

--
-- Table structure for table `dealer_type`
--

DROP TABLE IF EXISTS `dealer_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealer_type` (
  `dealer_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `dealer_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`dealer_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dealer_type`
--

LOCK TABLES `dealer_type` WRITE;
/*!40000 ALTER TABLE `dealer_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `dealer_type` VALUES (1,'Motor Vehicles'),(2,'Farm Equipment'),(3,'Trucks');
/*!40000 ALTER TABLE `dealer_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `dealer_type` with 3 row(s)
--

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `departments` VALUES (1,'Office of the Premier (OTP)'),(2,'Department of Agriculture'),(3,'Department of Education'),(4,'Department of Economic Development,Environmental Affairs'),(5,'Department of Health and Social Development'),(6,'Department of Cooperative Governance, Human Settlement'),(7,'Provincial Treasury'),(8,'Department of Public Works'),(9,'Department of Transport and Community Security'),(10,'Department Safety, Security and Liaison'),(11,'Department of Sport, Arts and Culture'),(12,'Other');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `departments` with 12 row(s)
--

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `districts` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `district` varchar(40) DEFAULT NULL,
  `station` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`district_id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `districts` VALUES (1,'Head Office :','Pool Section'),(2,'Head Office :','Manenu'),(3,'Head Office :','Traffic Management'),(4,'Head Office :','MEC Office'),(5,'Capricorn :','District Office'),(6,'Capricorn :','Seshego Govt Garage'),(9,'Capricorn :','Polokwane Traffic Station'),(10,'Capricorn :','Mogwadi Traffic Station'),(13,'Capricorn :','Mogwadi Traffic Station'),(14,'Capricorn :','Polokwane Weight Bridge'),(15,'Capricorn :','Lebowakgomo Traffic Station'),(16,'Capricorn :','Mokomene Traffic Station'),(17,'Sekhukhune:','Dilokong Traffic Station'),(18,'Sekhukhune:','District Office'),(22,'Sekhukhune:','Lebowakgomo Govt Garage'),(24,'Sekhukhune:','Moutse Traffic Station'),(26,'Sekhukhune:','Nebo Government Garage'),(27,'Sekhukhune:','Nebo Traffic Station'),(28,'Sekhukhune:','Rathoke Weighbridge'),(32,'Vhembe:','District Office'),(34,'Vhembe:','Makhado Traffic Station'),(35,'Vhembe:','Dzanani Traffic Station'),(37,'Vhembe:','Malamulele Traffic Station'),(38,'Vhembe:','Musina Weigh Bridge'),(39,'Vhembe:','Mutale Traffic Station'),(40,'Vhembe:','Sibasa Govt Garage'),(41,'Vhembe:','Thohoyandou Traffic Station'),(42,'Vhembe:','Mampakuil Weigh Bridge'),(43,'Vhembe:','Rabali Traffic Station'),(45,'Mopani:','Bolobedu Traffic Station'),(46,'Mopani:','District Office'),(50,'Mopani:','Giyani Traffic Station'),(51,'Mopani:','Giyani Government Garage'),(52,'Mopani:','Mooketsi T-C-Centre'),(55,'Mopani:','Hoedspruit Traffic Station'),(58,'Mopani:','Ba-Phalaborwa Traffic Station'),(63,'Mopani:','Naphuno Traffic Station'),(67,'Mopani:','Ritavi Traffic Station'),(70,'Mopani:','Tzaneen Traffic Station'),(71,'Mopani:','Maruleng Traffic Station'),(79,'Waterberg:','District Office'),(82,'Waterberg:','Groblersbrug Traffic Control'),(86,'Waterberg:','Lephalale Traffic Centre'),(87,'Waterberg:','Mahwelereng Govt Garage'),(88,'Waterberg:','Mantsole Traffic Centre'),(91,'Waterberg:','Modimolle Traffic Centre'),(94,'Waterberg:','Mokopane Traffic Station'),(98,'Waterberg:','Northam Traffic Station'),(99,'Waterberg:','Nylstroom Traffic Station'),(105,'Waterberg:','Zebetiela Traffic Control Centre'),(106,'Gauteng',NULL),(107,'Mpumalanga',NULL),(108,'North West',NULL),(109,'Free State',NULL),(110,'KwaZulu-Natal',NULL),(111,'Eastern Cape',NULL),(112,'Northern Cape',NULL),(113,'Western Cape',NULL),(114,'Botswana',NULL),(115,'Namibia',NULL),(116,'Zimbabwe',NULL),(117,'Malawia',NULL),(118,'Zambia',NULL);
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `districts` with 63 row(s)
--

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driver` (
  `driver_id` int(11) NOT NULL AUTO_INCREMENT,
  `drivers_name_and_surname` varchar(40) NOT NULL,
  `drivers_persal_number` varchar(40) NOT NULL,
  `drivers_contact_details` varchar(40) DEFAULT NULL,
  `drivers_email_address` varchar(40) DEFAULT NULL,
  `drivers_license` varchar(40) DEFAULT NULL,
  `drivers_license_code` varchar(40) DEFAULT NULL,
  `drivers_license_number` varchar(40) DEFAULT NULL,
  `drivers_license_upload` varchar(40) DEFAULT NULL,
  `drivers_license_expire_date` date DEFAULT NULL,
  `drivers_license_renewal_date` date DEFAULT NULL,
  `drivers_log_history` text,
  `drivers_license_penalties` varchar(40) DEFAULT NULL,
  `drivers_license_penalties_date` date DEFAULT NULL,
  `drivers_license_penalty_details` text,
  `drivers_license_penalty_details_uploads` varchar(40) DEFAULT NULL,
  `involved_in_accident` varchar(40) DEFAULT NULL,
  `accident_report` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`driver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `driver` VALUES (1,'Mara Kriel','82480397','015 295 1077','krielm@dot.limpopo.gov.za','Yes','EC-02','ABC1234DEF5678',NULL,'2017-07-11','2017-07-11','<br>','No','2017-07-11','<br>',NULL,'No',NULL);
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `driver` with 1 row(s)
--

--
-- Table structure for table `external_repairs_body`
--

DROP TABLE IF EXISTS `external_repairs_body`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `external_repairs_body` (
  `external_repair_body_id` int(11) NOT NULL AUTO_INCREMENT,
  `head_panel_beating_name` varchar(40) DEFAULT NULL,
  `head_panel_beating_contact_details` varchar(40) DEFAULT NULL,
  `head_panel_beating_address` text,
  `head_panel_beating_signature` varchar(40) DEFAULT NULL,
  `panel_beating_quotation` varchar(40) DEFAULT NULL,
  `service_provider_name` int(11) DEFAULT NULL,
  `service_provider_contact_details` int(11) DEFAULT NULL,
  `service_provider_address` int(11) DEFAULT NULL,
  `service_provider_signature` varchar(40) DEFAULT NULL,
  `vehicle_inspection_done` varchar(40) DEFAULT NULL,
  `vehicle_colour` int(11) DEFAULT NULL,
  `vehicle_tyre_sizes` varchar(40) DEFAULT NULL,
  `vehicle_mirrow_check` text,
  `vehicle_interior_condition` text,
  `vehicle_exterior_condition` text,
  `merchant_name` int(11) DEFAULT NULL,
  `merchant_contacts_details` int(11) DEFAULT NULL,
  `merchant_email_address` varchar(40) DEFAULT NULL,
  `merchant_signature` varchar(40) DEFAULT NULL,
  `merchant_address` int(11) DEFAULT NULL,
  `merchant_code` int(11) DEFAULT NULL,
  `merchant_city` int(11) DEFAULT NULL,
  `vehicle_inspection_report` varchar(40) DEFAULT NULL,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `instruction_note` int(11) DEFAULT NULL,
  `authorization_number` int(11) DEFAULT NULL,
  `merchant_type` int(11) DEFAULT NULL,
  `merchant_address_code` int(11) DEFAULT NULL,
  `panel_beating_quotation_approved_by_service_provider` varchar(40) DEFAULT NULL,
  `head_panel_beating_monitor_progress` varchar(40) DEFAULT NULL,
  `head_panel_beating_monitor_quality_of_work_manship` varchar(40) DEFAULT NULL,
  `vehicle_inspection_check_list_form` varchar(40) DEFAULT NULL,
  `service_provider_branch` int(11) DEFAULT NULL,
  `service_provider_branch_code` int(11) DEFAULT NULL,
  `service_provider_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`external_repair_body_id`),
  KEY `instruction_note` (`instruction_note`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `merchant_type` (`merchant_type`),
  KEY `merchant_code` (`merchant_code`),
  KEY `merchant_name` (`merchant_name`),
  KEY `merchant_contacts_details` (`merchant_contacts_details`),
  KEY `merchant_address` (`merchant_address`),
  KEY `merchant_address_code` (`merchant_address_code`),
  KEY `merchant_city` (`merchant_city`),
  KEY `service_provider_name` (`service_provider_name`),
  KEY `service_provider_type` (`service_provider_type`),
  KEY `service_provider_contact_details` (`service_provider_contact_details`),
  KEY `service_provider_branch` (`service_provider_branch`),
  KEY `service_provider_branch_code` (`service_provider_branch_code`),
  KEY `service_provider_address` (`service_provider_address`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_repairs_body`
--

LOCK TABLES `external_repairs_body` WRITE;
/*!40000 ALTER TABLE `external_repairs_body` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `external_repairs_body` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `external_repairs_body` with 0 row(s)
--

--
-- Table structure for table `external_repairs_mechanical`
--

DROP TABLE IF EXISTS `external_repairs_mechanical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `external_repairs_mechanical` (
  `external_mechanical_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_provider_name` int(11) DEFAULT NULL,
  `service_provider_contact_details` int(11) DEFAULT NULL,
  `service_provider_address` int(11) DEFAULT NULL,
  `service_provider_signature` varchar(40) DEFAULT NULL,
  `repair_requirement_note` text,
  `merchant_name` int(11) DEFAULT NULL,
  `merchant_contacts_details` int(11) DEFAULT NULL,
  `merchant_email_address` int(11) DEFAULT NULL,
  `merchant_signature` varchar(40) DEFAULT NULL,
  `merchant_address` int(11) DEFAULT NULL,
  `service_provider_repair_quote` text,
  `inspection_approval_repair_note` text,
  `department_authorization_quote` varchar(40) DEFAULT NULL,
  `department_inspector_name_and_surname` varchar(40) DEFAULT NULL,
  `department_inspector_persal_number` varchar(40) DEFAULT NULL,
  `department_inspector_signature` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `instruction_note` int(11) DEFAULT NULL,
  `authorization_number` int(11) DEFAULT NULL,
  `date_of_vehicle_send` datetime DEFAULT NULL,
  `date_of_vehicle_received` datetime DEFAULT NULL,
  `service_provider_repair_quote_upload` varchar(40) DEFAULT NULL,
  `department_authorization_quote_note` text,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  `merchant_code` int(11) DEFAULT NULL,
  `merchant_type` int(11) DEFAULT NULL,
  `merchant_address_code` int(11) DEFAULT NULL,
  `mechanical_repair_progress_monitor` varchar(40) DEFAULT NULL,
  `mechanical_repair_progress_monitor_quality_of_work_manship` varchar(40) DEFAULT NULL,
  `vehicle_inspection_report` varchar(40) DEFAULT NULL,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `service_provider_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`external_mechanical_id`),
  KEY `authorization_number` (`authorization_number`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `merchant_type` (`merchant_type`),
  KEY `merchant_code` (`merchant_code`),
  KEY `merchant_name` (`merchant_name`),
  KEY `merchant_contacts_details` (`merchant_contacts_details`),
  KEY `merchant_email_address` (`merchant_email_address`),
  KEY `merchant_address` (`merchant_address`),
  KEY `merchant_address_code` (`merchant_address_code`),
  KEY `service_provider_name` (`service_provider_name`),
  KEY `service_provider_type` (`service_provider_type`),
  KEY `service_provider_contact_details` (`service_provider_contact_details`),
  KEY `service_provider_address` (`service_provider_address`),
  KEY `instruction_note` (`instruction_note`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_repairs_mechanical`
--

LOCK TABLES `external_repairs_mechanical` WRITE;
/*!40000 ALTER TABLE `external_repairs_mechanical` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `external_repairs_mechanical` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `external_repairs_mechanical` with 0 row(s)
--

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `forms_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_daily_check_list_and_appraisal_report` varchar(40) DEFAULT NULL,
  `approved_workshop_procedure_manual` varchar(40) DEFAULT NULL,
  `government_motor_transport_handbook` varchar(40) DEFAULT NULL,
  `z181_report_on_accident` varchar(40) DEFAULT NULL,
  `vehicle_handing_over_ckecklist` varchar(40) DEFAULT NULL,
  `vehicle_return_list` varchar(40) DEFAULT NULL,
  `indicates_and_list_details_of_damages_deficiencies` varchar(40) DEFAULT NULL,
  `vehicle_return_list_1` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`forms_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `forms` VALUES (1,'Vehicle_Check_List_And_Appraisal_Report.','WORKSHOP_PROCEDURE_MANUAL_2019_APPROVED.','Government_Motor_Transport_Handbook.pdf','Z181_Report_on_Accident.PDF','Vehicle_Handing_Over_Ckecklist.pdf','Vehicle__Return_List.pdf','Indicates_and_list_details_of_damages_de',NULL);
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `forms` with 1 row(s)
--

--
-- Table structure for table `fuel_type`
--

DROP TABLE IF EXISTS `fuel_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuel_type` (
  `fuel_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `fuel_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`fuel_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuel_type`
--

LOCK TABLES `fuel_type` WRITE;
/*!40000 ALTER TABLE `fuel_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `fuel_type` VALUES (1,'Petrol - 93 Octaan'),(2,'Petrol - 95 Octaan'),(3,'Diesel'),(4,'Gasoline'),(5,'Ethanol'),(6,'Biodiesel'),(7,'Propane'),(8,'Hydrogen');
/*!40000 ALTER TABLE `fuel_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `fuel_type` with 8 row(s)
--

--
-- Table structure for table `gate_security`
--

DROP TABLE IF EXISTS `gate_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gate_security` (
  `gate_security_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `gate_security_name_and_surname` varchar(40) DEFAULT NULL,
  `gate_security_contact_details` varchar(40) DEFAULT NULL,
  `gate_security_signature` varchar(40) NOT NULL,
  `vehicle_inspection` varchar(40) DEFAULT NULL,
  `vehicle_colour` int(11) DEFAULT NULL,
  `vehicle_tires_size` varchar(40) DEFAULT NULL,
  `vehicle_tires_check` varchar(40) DEFAULT NULL,
  `vehicle_mirrow_check` varchar(40) DEFAULT NULL,
  `vehicle_interiour_condition` text,
  `vehicle_exteriour_condition` text,
  `gate_security_company_name` varchar(40) DEFAULT NULL,
  `gate_security_company_contact_details` varchar(40) DEFAULT NULL,
  `gate_security_manager_name_and_surname` varchar(40) DEFAULT NULL,
  `gate_security_manager_contact_details` varchar(40) DEFAULT NULL,
  `gate_security_company_address` text,
  `inspection_of_vehicle_report` varchar(40) DEFAULT NULL,
  `record_of_vehicle` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) NOT NULL,
  `engine_number` int(11) NOT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `vehicle_model` varchar(40) DEFAULT NULL,
  `date_of_vehicle_entrance` datetime DEFAULT NULL,
  `date_of_vehicle_exit` datetime DEFAULT NULL,
  PRIMARY KEY (`gate_security_user_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gate_security`
--

LOCK TABLES `gate_security` WRITE;
/*!40000 ALTER TABLE `gate_security` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `gate_security` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `gate_security` with 0 row(s)
--

--
-- Table structure for table `general_control_measures`
--

DROP TABLE IF EXISTS `general_control_measures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_control_measures` (
  `general_control_measures_id` int(11) NOT NULL AUTO_INCREMENT,
  `government_garage_name` int(11) DEFAULT NULL,
  `government_garage_section` varchar(40) DEFAULT NULL,
  `government_garage_station` int(11) DEFAULT NULL,
  `government_garage_address` text,
  `government_garage_condition` varchar(40) DEFAULT NULL,
  `four_post_lift_condition` varchar(40) DEFAULT NULL,
  `low_level_lift_condition` varchar(40) DEFAULT NULL,
  `test_machines_conditions` varchar(40) DEFAULT NULL,
  `battery_testers_conditions` varchar(40) DEFAULT NULL,
  `chargers_conditions` varchar(40) DEFAULT NULL,
  `tools_conditions` int(11) DEFAULT NULL,
  `hand_tools_conditions` int(11) DEFAULT NULL,
  `equipment_conditions` varchar(40) DEFAULT NULL,
  `sectional_inspection` varchar(40) DEFAULT NULL,
  `government_garage_manager_name_and_surname` varchar(40) DEFAULT NULL,
  `government_garage_manager_contact_details` varchar(40) DEFAULT NULL,
  `government_garage_manager_email_address` varchar(40) DEFAULT NULL,
  `government_garage_manager_signature` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`general_control_measures_id`),
  KEY `tools_conditions` (`tools_conditions`),
  KEY `hand_tools_conditions` (`hand_tools_conditions`),
  KEY `government_garage_station` (`government_garage_station`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_control_measures`
--

LOCK TABLES `general_control_measures` WRITE;
/*!40000 ALTER TABLE `general_control_measures` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `general_control_measures` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `general_control_measures` with 0 row(s)
--

--
-- Table structure for table `gmt_fleet_register`
--

DROP TABLE IF EXISTS `gmt_fleet_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gmt_fleet_register` (
  `fleet_asset_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_registration_number` varchar(25) NOT NULL,
  `engine_number` varchar(35) NOT NULL,
  `chassis_number` varchar(35) NOT NULL,
  `dealer_name` int(11) DEFAULT NULL,
  `model_of_vehicle` varchar(45) DEFAULT NULL,
  `year_model_specification` int(11) NOT NULL,
  `engine_capacity` varchar(40) DEFAULT NULL,
  `tyre_size` varchar(40) DEFAULT NULL,
  `transmission` int(11) DEFAULT NULL,
  `fuel_type` int(11) DEFAULT NULL,
  `type_of_vehicle` int(11) NOT NULL,
  `colour_of_vehicle` int(11) NOT NULL,
  `application_status` int(11) NOT NULL,
  `barcode_number` varchar(35) DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `depreciation_value` varchar(40) DEFAULT NULL,
  `photo_of_vehicle` varchar(255) DEFAULT NULL,
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(40) NOT NULL,
  `contact_number` varchar(16) NOT NULL,
  `department_name` int(11) NOT NULL,
  `department_address` text NOT NULL,
  `province` int(11) NOT NULL,
  `district` int(11) NOT NULL,
  `drivers_name_and_surname` int(11) DEFAULT NULL,
  `drivers_persal_number` int(11) DEFAULT NULL,
  `department_name_of_driver` int(11) DEFAULT NULL,
  `drivers_contact_details` int(11) DEFAULT NULL,
  `documents` varchar(225) DEFAULT NULL,
  `date_auctioned` date DEFAULT '0000-00-00',
  `comments` longtext,
  `renewal_of_license` date DEFAULT NULL,
  `mm_code` varchar(40) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  PRIMARY KEY (`fleet_asset_id`),
  UNIQUE KEY `vehicle_registration_number_unique` (`vehicle_registration_number`),
  UNIQUE KEY `engine_number_unique` (`engine_number`),
  UNIQUE KEY `chassis_number_unique` (`chassis_number`),
  UNIQUE KEY `barcode_number_unique` (`barcode_number`),
  KEY `dealer_name` (`dealer_name`),
  KEY `year_model_specification` (`year_model_specification`),
  KEY `transmission` (`transmission`),
  KEY `fuel_type` (`fuel_type`),
  KEY `type_of_vehicle` (`type_of_vehicle`),
  KEY `colour_of_vehicle` (`colour_of_vehicle`),
  KEY `application_status` (`application_status`),
  KEY `department_name` (`department_name`),
  KEY `province` (`province`),
  KEY `district` (`district`),
  KEY `department_name_of_driver` (`department_name_of_driver`),
  KEY `drivers_name_and_surname` (`drivers_name_and_surname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmt_fleet_register`
--

LOCK TABLES `gmt_fleet_register` WRITE;
/*!40000 ALTER TABLE `gmt_fleet_register` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `gmt_fleet_register` VALUES (1,'004DTNL','VQ40581028','VSKCLND40Z0238318',3,'NAVARA 4.0 A/T 4X4',11,'1950','17',1,2,6,25,1,'123456789987654321',375787.67,'355643.76',NULL,'THOMAS','LEKGOTHOANE','0152951000',9,'PRIVATE BAGX 9491<div>POLOKWANE<br></div><div>0700</div>',1,9,1,1,9,1,'ApplicationForm1B_(2).pdf','0000-00-00','<br>','2019-09-24','123LDoTaCS-2019',3);
/*!40000 ALTER TABLE `gmt_fleet_register` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `gmt_fleet_register` with 1 row(s)
--

--
-- Table structure for table `identification_of_defects`
--

DROP TABLE IF EXISTS `identification_of_defects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identification_of_defects` (
  `defects_id` int(11) NOT NULL AUTO_INCREMENT,
  `end_user_name_and_surname` varchar(40) DEFAULT NULL,
  `end_user_contact_details` varchar(40) DEFAULT NULL,
  `end_user_persal_number` varchar(40) DEFAULT NULL,
  `end_user_email_address` varchar(40) DEFAULT NULL,
  `end_user_signature` varchar(40) DEFAULT NULL,
  `types_of_defects` text,
  `courses_of_defects` text,
  `condition_of_defects` text,
  `transport_officer_name_and_surname` varchar(40) DEFAULT NULL,
  `transport_officer_persal_number` varchar(40) DEFAULT NULL,
  `transport_officer_contact_details` varchar(40) DEFAULT NULL,
  `transport_officer_email_address` varchar(40) DEFAULT NULL,
  `government_garage_manager_name_and_surname` varchar(40) DEFAULT NULL,
  `government_garage_manager_contact_details` varchar(40) DEFAULT NULL,
  `government_garage_manager_address` text,
  `government_garage_manager_email_address` varchar(40) DEFAULT NULL,
  `government_garage_manager_signature` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  PRIMARY KEY (`defects_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identification_of_defects`
--

LOCK TABLES `identification_of_defects` WRITE;
/*!40000 ALTER TABLE `identification_of_defects` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `identification_of_defects` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `identification_of_defects` with 0 row(s)
--

--
-- Table structure for table `indicates_repair_damages_found_list`
--

DROP TABLE IF EXISTS `indicates_repair_damages_found_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicates_repair_damages_found_list` (
  `repair_damages_list_id` int(11) NOT NULL AUTO_INCREMENT,
  `brought_in_for_repairs` text,
  `after_repairs` text,
  `driver_name_and_surname` int(11) DEFAULT NULL,
  `driver_persal_number` int(11) DEFAULT NULL,
  `driver_signature` varchar(40) DEFAULT NULL,
  `vehicle_return_date_signed` datetime DEFAULT '2020-01-01 00:00:00',
  `company_name_and_surname` varchar(40) DEFAULT NULL,
  `company_repesentative_signature` varchar(40) DEFAULT NULL,
  `vehicle_return_date_signed_by_representative` datetime DEFAULT '2020-01-01 00:00:00',
  `indicates_and_list_details_of_damages_deficiencies` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`repair_damages_list_id`),
  KEY `driver_name_and_surname` (`driver_name_and_surname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicates_repair_damages_found_list`
--

LOCK TABLES `indicates_repair_damages_found_list` WRITE;
/*!40000 ALTER TABLE `indicates_repair_damages_found_list` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `indicates_repair_damages_found_list` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `indicates_repair_damages_found_list` with 0 row(s)
--

--
-- Table structure for table `inspection_bay`
--

DROP TABLE IF EXISTS `inspection_bay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inspection_bay` (
  `inspection_bay_id` int(11) NOT NULL AUTO_INCREMENT,
  `inspection_bay_supervisor_name` varchar(40) DEFAULT NULL,
  `supervisor_contact_details` varchar(40) DEFAULT NULL,
  `supervisor_email_address` varchar(40) DEFAULT NULL,
  `supervisor_signature` varchar(40) DEFAULT NULL,
  `inspection_bay_lane_number` varchar(40) DEFAULT NULL,
  `inspection_bay_condition` text,
  `allocation_feedback` text,
  `verification_of_defects` text,
  `additional_defects` text,
  `additional_defects_record` varchar(40) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `date_of_vehicle_entrance` datetime DEFAULT NULL,
  `date_of_vehicle_exit` datetime DEFAULT NULL,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  `repair_requirement_report_1` varchar(40) DEFAULT NULL,
  `repair_requirement_report` varchar(40) DEFAULT NULL,
  `repair_requirement_note` text,
  PRIMARY KEY (`inspection_bay_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `job_card_number` (`job_card_number`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inspection_bay`
--

LOCK TABLES `inspection_bay` WRITE;
/*!40000 ALTER TABLE `inspection_bay` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `inspection_bay` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `inspection_bay` with 0 row(s)
--

--
-- Table structure for table `insurance_payments`
--

DROP TABLE IF EXISTS `insurance_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_payments` (
  `insurance_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `engine_number` int(6) DEFAULT NULL,
  `chassis_number` int(6) DEFAULT NULL,
  `make_of_vehicle` int(6) DEFAULT NULL,
  `model_of_vehicle` int(6) DEFAULT NULL,
  `year_model_of_vehicle` int(6) DEFAULT NULL,
  `type_of_vehicle` int(6) DEFAULT NULL,
  `application_status` int(6) DEFAULT NULL,
  `barcode_number` int(6) DEFAULT NULL,
  `department` int(6) DEFAULT NULL,
  `insurance_reference` varchar(40) DEFAULT NULL,
  `insurance_expiration` date DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `reference_number` varchar(40) DEFAULT NULL,
  `merchant_name` int(11) DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `month_end` date DEFAULT NULL,
  `documents` varchar(40) DEFAULT NULL,
  `comments` longtext,
  PRIMARY KEY (`insurance_payment_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `merchant_name` (`merchant_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_payments`
--

LOCK TABLES `insurance_payments` WRITE;
/*!40000 ALTER TABLE `insurance_payments` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `insurance_payments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `insurance_payments` with 0 row(s)
--

--
-- Table structure for table `internal_repairs_body`
--

DROP TABLE IF EXISTS `internal_repairs_body`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_repairs_body` (
  `internal_repairs_body_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_name_and_surname` int(11) DEFAULT NULL,
  `driver_persal_number` int(11) DEFAULT NULL,
  `driver_contacts_details` int(11) DEFAULT NULL,
  `driver_email_address` int(11) DEFAULT NULL,
  `driver_license_code` int(11) DEFAULT NULL,
  `driver_license_number` int(11) DEFAULT NULL,
  `driver_license_upload` varchar(40) DEFAULT NULL,
  `driver_signature` varchar(40) DEFAULT NULL,
  `z181_accident_form` varchar(40) DEFAULT NULL,
  `z181_accident_form_uploaded` varchar(40) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `government_garage_name` int(11) DEFAULT NULL,
  `government_garage_contact_details` varchar(40) DEFAULT NULL,
  `government_garage_address` text,
  `government_garage_email_address` varchar(40) DEFAULT NULL,
  `damages_occured` text,
  `head_panel_beating_quotation` varchar(40) DEFAULT NULL,
  `head_panel_beating_name` varchar(40) DEFAULT NULL,
  `head_panel_beating_contact_details` varchar(40) DEFAULT NULL,
  `head_panel_beating_address` text,
  `head_panel_beating_signature` varchar(40) DEFAULT NULL,
  `private_panel_beating_name` varchar(40) DEFAULT NULL,
  `private_panel_beating_contact_details` varchar(40) DEFAULT NULL,
  `private_panel_beating_address` text,
  `private_panel_beating_quotation` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `head_panel_beating_quotation_1` varchar(40) DEFAULT NULL,
  `private_panel_beating_quotation_2` varchar(40) DEFAULT NULL,
  `upload_of_internal_damages_1` varchar(40) DEFAULT NULL,
  `upload_of_internal_damages_4` varchar(40) DEFAULT NULL,
  `upload_of_internal_damages_2` varchar(40) DEFAULT NULL,
  `upload_of_internal_damages_3` varchar(40) DEFAULT NULL,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  `artisan_note_of_starting_time` datetime DEFAULT NULL,
  `artisan_note_of_completion_time` datetime DEFAULT NULL,
  `total_labour_time` time DEFAULT NULL,
  PRIMARY KEY (`internal_repairs_body_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `driver_name_and_surname` (`driver_name_and_surname`),
  KEY `job_card_number` (`job_card_number`),
  KEY `government_garage_name` (`government_garage_name`),
  KEY `driver_license_code` (`driver_license_code`),
  KEY `driver_license_number` (`driver_license_number`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `internal_repairs_body`
--

LOCK TABLES `internal_repairs_body` WRITE;
/*!40000 ALTER TABLE `internal_repairs_body` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `internal_repairs_body` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `internal_repairs_body` with 0 row(s)
--

--
-- Table structure for table `internal_repairs_mechanical`
--

DROP TABLE IF EXISTS `internal_repairs_mechanical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_repairs_mechanical` (
  `internal_mechanical_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `artisan_name_and_surname` varchar(40) DEFAULT NULL,
  `artisan_contacts` varchar(40) DEFAULT NULL,
  `artisan_email_address` varchar(40) DEFAULT NULL,
  `artisan_signature` varchar(40) DEFAULT NULL,
  `artisan_note_of_starting_time` datetime DEFAULT NULL,
  `pre_repair_inspections` text,
  `artisan_dismantling_solution` text,
  `spares_order_quotation` varchar(40) DEFAULT NULL,
  `spares_order_description` text,
  `artisan_note_of_completion_time` datetime DEFAULT NULL,
  `inspection_bay_lane_number` int(11) DEFAULT NULL,
  `inspection_bay_report` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `total_labour_time` time DEFAULT NULL,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`internal_mechanical_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `workshop_name` (`workshop_name`),
  KEY `inspection_bay_lane_number` (`inspection_bay_lane_number`),
  KEY `job_card_number` (`job_card_number`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `internal_repairs_mechanical`
--

LOCK TABLES `internal_repairs_mechanical` WRITE;
/*!40000 ALTER TABLE `internal_repairs_mechanical` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `internal_repairs_mechanical` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `internal_repairs_mechanical` with 0 row(s)
--

--
-- Table structure for table `log_sheet`
--

DROP TABLE IF EXISTS `log_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_sheet` (
  `fuel_log_sheet_id` int(11) NOT NULL AUTO_INCREMENT,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `model_of_vehicle` int(11) DEFAULT NULL,
  `district` int(6) DEFAULT NULL,
  `month` date DEFAULT NULL,
  `year_model_specification` int(6) DEFAULT NULL,
  `year_model` varchar(40) DEFAULT NULL,
  `drivers_name_and_surname` int(11) DEFAULT NULL,
  `drivers_persal_number` int(11) DEFAULT NULL,
  `opening_km` varchar(15) NOT NULL,
  `closing_km` varchar(15) NOT NULL,
  `total_km` varchar(15) DEFAULT NULL,
  `engine_capacity` int(6) DEFAULT NULL,
  `fuel_type` int(11) DEFAULT NULL,
  `fuel_tank_capacity` decimal(10,2) DEFAULT '0.00',
  `vendor` varchar(40) DEFAULT NULL,
  `fuel_cost_litre` decimal(10,2) DEFAULT '0.00',
  `refuel_quantity_1` decimal(10,2) DEFAULT '0.00',
  `refuel_first_time_date` date DEFAULT NULL,
  `refuel_quantity_2` decimal(10,2) DEFAULT '0.00',
  `refuel_second_time_date` date DEFAULT NULL,
  `refuel_quantity_3` decimal(10,2) DEFAULT '0.00',
  `refuel_third_time_date` date DEFAULT NULL,
  `refuel_quantity_4` decimal(10,2) DEFAULT '0.00',
  `refuel_fourth_time_date` date DEFAULT NULL,
  `times_refuel_current_month` decimal(10,2) DEFAULT NULL,
  `total_fuel_quantity` decimal(10,2) DEFAULT '0.00',
  `fuel_consumption` decimal(10,2) DEFAULT '0.00',
  `fuel_total_cost` decimal(10,2) DEFAULT '0.00',
  `payment_e_fuel_card` varchar(40) DEFAULT NULL,
  `captured_by` varchar(35) NOT NULL,
  `comments` text,
  `date_captured` date DEFAULT NULL,
  `complete_fill_up` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`fuel_log_sheet_id`),
  KEY `drivers_surname` (`drivers_name_and_surname`),
  KEY `fuel_type` (`fuel_type`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_sheet`
--

LOCK TABLES `log_sheet` WRITE;
/*!40000 ALTER TABLE `log_sheet` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `log_sheet` VALUES (1,1,1,1,NULL,1,NULL,1,1,'2456.76','2843.76','387',1,3,50.00,'Engen - Mokopane',16.36,34.00,'2020-02-01',40.00,'2020-02-10',0.00,'2020-02-10',0.00,'2020-02-10',2.00,74.00,5.23,1210.64,NULL,'Mara Kriel','<br>',NULL,NULL,1);
/*!40000 ALTER TABLE `log_sheet` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `log_sheet` with 1 row(s)
--

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturer` (
  `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer_type` int(11) DEFAULT NULL,
  `manufacturer_name` varchar(40) DEFAULT NULL,
  `contact_person` varchar(40) DEFAULT NULL,
  `contact_details` varchar(40) DEFAULT NULL,
  `contact_email` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`manufacturer_id`),
  KEY `manufacturer_type` (`manufacturer_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer`
--

LOCK TABLES `manufacturer` WRITE;
/*!40000 ALTER TABLE `manufacturer` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `manufacturer` VALUES (1,4,'Bosch',NULL,NULL,NULL),(2,2,'Bearing man',NULL,NULL,NULL),(3,3,'ZamOIL',NULL,NULL,NULL),(4,1,'Castor Helix',NULL,NULL,NULL),(5,6,'GUD',NULL,NULL,NULL);
/*!40000 ALTER TABLE `manufacturer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `manufacturer` with 5 row(s)
--

--
-- Table structure for table `manufacturer_type`
--

DROP TABLE IF EXISTS `manufacturer_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturer_type` (
  `manufacturer_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`manufacturer_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer_type`
--

LOCK TABLES `manufacturer_type` WRITE;
/*!40000 ALTER TABLE `manufacturer_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `manufacturer_type` VALUES (1,'Oil'),(2,'Bearings'),(3,'Oil Filter'),(4,'Bushes'),(5,'Brake pads'),(6,'Air Filter');
/*!40000 ALTER TABLE `manufacturer_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `manufacturer_type` with 6 row(s)
--

--
-- Table structure for table `membership_grouppermissions`
--

DROP TABLE IF EXISTS `membership_grouppermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupID` int(10) unsigned DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) NOT NULL DEFAULT '0',
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permissionID`),
  UNIQUE KEY `groupID_tableName` (`groupID`,`tableName`)
) ENGINE=InnoDB AUTO_INCREMENT=2332 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_grouppermissions`
--

LOCK TABLES `membership_grouppermissions` WRITE;
/*!40000 ALTER TABLE `membership_grouppermissions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `membership_grouppermissions` VALUES (1,2,'gmt_fleet_register',1,3,3,3),(2,2,'log_sheet',1,3,3,3),(3,2,'vehicle_history',1,3,3,3),(4,2,'year_model',1,3,3,3),(5,2,'month',1,3,3,3),(6,2,'body_type',1,3,3,3),(7,2,'vehicle_colour',1,3,3,3),(8,2,'province',1,3,3,3),(9,2,'departments',1,3,3,3),(10,2,'districts',1,3,3,3),(11,2,'application_status',1,3,3,3),(12,2,'vehicle_payments',1,3,3,3),(13,2,'insurance_payments',1,3,3,3),(14,2,'authorizations',1,3,3,3),(15,2,'service_schedule',1,3,3,3),(16,2,'service_type',1,3,3,3),(17,2,'service_categories',1,3,3,3),(18,2,'service_item_type',1,3,3,3),(19,2,'service_item',1,3,3,3),(20,2,'purchase_orders',1,3,3,3),(21,2,'transmission',1,3,3,3),(22,2,'fuel_type',1,3,3,3),(23,2,'merchant',1,3,3,3),(24,2,'merchant_type',1,3,3,3),(25,2,'manufacturer',1,3,3,3),(26,2,'manufacturer_type',1,3,3,3),(27,2,'driver',1,3,3,3),(28,2,'accidents',1,3,3,3),(29,2,'accident_type',1,3,3,3),(30,2,'claim',1,3,3,3),(31,2,'claim_status',1,3,3,3),(32,2,'claim_category',1,3,3,3),(33,2,'cost_centre',1,3,3,3),(34,2,'dealer',1,3,3,3),(35,2,'dealer_type',1,3,3,3),(36,2,'tyre_log_sheet',1,3,3,3),(37,2,'vehicle_daily_check_list',1,3,3,3),(38,2,'auditor',1,3,3,3),(39,2,'parts',1,3,3,3),(40,2,'parts_type',1,3,3,3),(41,2,'breakdowns',1,3,3,3),(42,2,'modification_to_vehicle',1,3,3,3),(180,2,'vehicle_handing_over_checklist',1,3,3,3),(224,2,'vehicle_return_check_list',1,3,3,3),(269,2,'indicates_repair_damages_found_list',1,3,3,3),(315,2,'forms',1,3,3,3),(638,12,'gmt_fleet_register',0,3,3,3),(639,12,'log_sheet',0,3,3,3),(640,12,'vehicle_history',0,3,3,3),(641,12,'year_model',0,3,3,3),(642,12,'month',0,3,0,0),(643,12,'body_type',0,3,0,0),(644,12,'vehicle_colour',0,3,0,0),(645,12,'province',0,3,0,0),(646,12,'departments',0,3,0,0),(647,12,'districts',0,3,0,0),(648,12,'application_status',0,3,0,0),(649,12,'vehicle_payments',0,3,0,0),(650,12,'insurance_payments',0,3,0,0),(651,12,'authorizations',0,3,3,3),(652,12,'service_schedule',0,3,3,3),(653,12,'service_type',0,3,3,3),(654,12,'service_categories',0,0,0,0),(655,12,'service_item_type',0,3,3,3),(656,12,'service_item',0,3,3,3),(657,12,'purchase_orders',0,3,3,3),(658,12,'transmission',0,3,0,0),(659,12,'fuel_type',0,3,0,0),(660,12,'merchant',0,3,3,3),(661,12,'merchant_type',0,3,3,3),(662,12,'manufacturer',0,3,3,3),(663,12,'manufacturer_type',0,3,3,3),(664,12,'driver',1,3,3,3),(665,12,'accidents',1,3,3,3),(666,12,'accident_type',1,3,3,3),(667,12,'claim',1,3,3,3),(668,12,'claim_status',1,3,3,3),(669,12,'claim_category',1,3,3,3),(670,12,'cost_centre',1,3,3,3),(671,12,'dealer',1,3,3,3),(672,12,'dealer_type',1,3,3,3),(673,12,'tyre_log_sheet',1,3,3,3),(674,12,'vehicle_daily_check_list',1,3,3,3),(675,12,'auditor',0,3,0,0),(676,12,'parts',1,3,3,3),(677,12,'parts_type',1,3,3,3),(678,12,'breakdowns',1,3,3,3),(679,12,'modification_to_vehicle',1,3,3,3),(680,12,'vehicle_handing_over_checklist',1,3,3,3),(681,12,'vehicle_return_check_list',1,3,3,3),(682,12,'indicates_repair_damages_found_list',1,3,3,3),(683,12,'forms',0,3,3,3),(730,11,'gmt_fleet_register',1,3,3,3),(731,11,'log_sheet',1,3,3,3),(732,11,'vehicle_history',1,3,3,3),(733,11,'year_model',0,3,3,3),(734,11,'month',0,3,3,3),(735,11,'body_type',0,3,3,3),(736,11,'vehicle_colour',0,3,3,3),(737,11,'province',0,3,3,3),(738,11,'departments',1,3,3,3),(739,11,'districts',1,3,3,3),(740,11,'application_status',1,3,3,3),(741,11,'vehicle_payments',1,3,3,3),(742,11,'insurance_payments',1,3,3,3),(743,11,'authorizations',0,0,0,0),(744,11,'service_schedule',0,0,0,0),(745,11,'service_type',0,0,0,0),(746,11,'service_categories',0,0,0,0),(747,11,'service_item_type',0,0,0,0),(748,11,'service_item',0,0,0,0),(749,11,'purchase_orders',0,0,0,0),(750,11,'transmission',0,0,0,0),(751,11,'fuel_type',0,0,0,0),(752,11,'merchant',0,0,0,0),(753,11,'merchant_type',0,0,0,0),(754,11,'manufacturer',0,0,0,0),(755,11,'manufacturer_type',0,0,0,0),(756,11,'driver',0,0,0,0),(757,11,'accidents',1,3,3,3),(758,11,'accident_type',1,3,3,3),(759,11,'claim',0,0,0,0),(760,11,'claim_status',0,0,0,0),(761,11,'claim_category',0,0,0,0),(762,11,'cost_centre',0,0,0,0),(763,11,'dealer',0,0,0,0),(764,11,'dealer_type',0,0,0,0),(765,11,'tyre_log_sheet',0,0,0,0),(766,11,'vehicle_daily_check_list',0,0,0,0),(767,11,'auditor',0,0,0,0),(768,11,'parts',0,0,0,0),(769,11,'parts_type',0,0,0,0),(770,11,'breakdowns',0,0,0,0),(771,11,'modification_to_vehicle',0,0,0,0),(772,11,'vehicle_handing_over_checklist',0,0,0,0),(773,11,'vehicle_return_check_list',0,0,0,0),(774,11,'indicates_repair_damages_found_list',0,0,0,0),(775,11,'forms',0,3,0,0),(822,2,'breakdown_services',1,3,3,3),(823,2,'identification_of_defects',1,3,3,3),(824,2,'gate_security',1,3,3,3),(825,2,'reception',1,3,3,3),(826,2,'inspection_bay',1,3,3,3),(827,2,'work_allocation',1,3,3,3),(828,2,'internal_repairs_mechanical',1,3,3,3),(829,2,'external_repairs_mechanical',1,3,3,3),(830,2,'internal_repairs_body',1,3,3,3),(831,2,'external_repairs_body',1,3,3,3),(832,2,'ordering_of_spares_for_internal_repairs',1,3,3,3),(833,2,'collection_of_repaired_vehicles',1,3,3,3),(834,2,'withdrawal_vehicle_from_operation',1,3,3,3),(835,2,'costing',1,3,3,3),(836,2,'billing',1,3,3,3),(837,2,'general_control_measures',1,3,3,3),(838,2,'movement_of_personnel_in_government_garage_and_workshops',1,3,3,3),(1882,2,'service_provider',1,3,3,3),(1883,2,'service_provider_type',1,3,3,3);
/*!40000 ALTER TABLE `membership_grouppermissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `membership_grouppermissions` with 157 row(s)
--

--
-- Table structure for table `membership_groups`
--

DROP TABLE IF EXISTS `membership_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_groups` (
  `groupID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`groupID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_groups`
--

LOCK TABLES `membership_groups` WRITE;
/*!40000 ALTER TABLE `membership_groups` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `membership_groups` VALUES (1,'anonymous','Anonymous group created automatically on 2019-12-17',0,0),(2,'Admins','Admin group created automatically on 2019-12-17',0,1),(11,'Data Capturers - Normal Fleet','Users that capture  details into the different tables based on their roles and privileges - Normal Fleet functions',0,1),(12,'Data Capturers - Workshop and Government Garages','Users that capture  details into the different tables based on their roles and privileges - Workshop and Government Garages functions',0,1);
/*!40000 ALTER TABLE `membership_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `membership_groups` with 4 row(s)
--

--
-- Table structure for table `membership_userpermissions`
--

DROP TABLE IF EXISTS `membership_userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `memberID` varchar(100) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) NOT NULL DEFAULT '0',
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permissionID`),
  UNIQUE KEY `memberID_tableName` (`memberID`,`tableName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_userpermissions`
--

LOCK TABLES `membership_userpermissions` WRITE;
/*!40000 ALTER TABLE `membership_userpermissions` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `membership_userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `membership_userpermissions` with 0 row(s)
--

--
-- Table structure for table `membership_userrecords`
--

DROP TABLE IF EXISTS `membership_userrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(100) DEFAULT NULL,
  `dateAdded` bigint(20) unsigned DEFAULT NULL,
  `dateUpdated` bigint(20) unsigned DEFAULT NULL,
  `groupID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`recID`),
  UNIQUE KEY `tableName_pkValue` (`tableName`,`pkValue`(150)),
  KEY `pkValue` (`pkValue`),
  KEY `tableName` (`tableName`),
  KEY `memberID` (`memberID`),
  KEY `groupID` (`groupID`)
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_userrecords`
--

LOCK TABLES `membership_userrecords` WRITE;
/*!40000 ALTER TABLE `membership_userrecords` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `membership_userrecords` VALUES (1,'service_item_type','1','whoami',1576673386,1576674381,2),(2,'service_item_type','2','whoami',1576673420,1576674393,2),(3,'service_item_type','3','whoami',1576673446,1576674409,2),(4,'service_item_type','4','whoami',1576673480,1576674422,2),(5,'service_item_type','5','whoami',1576673502,1576673502,2),(6,'service_item_type','6','whoami',1576673532,1576674433,2),(7,'service_item_type','7','whoami',1576673555,1576674448,2),(8,'service_item_type','8','whoami',1576673581,1576674462,2),(9,'service_item_type','9','whoami',1576673615,1576674474,2),(10,'service_item_type','10','whoami',1576673649,1576674489,2),(11,'service_item_type','11','whoami',1576673681,1576674514,2),(12,'service_item_type','12','whoami',1576673724,1576673724,2),(13,'service_item_type','13','whoami',1576673764,1576673764,2),(14,'service_item_type','14','whoami',1576673791,1576673831,2),(15,'service_item_type','15','whoami',1576673817,1576673817,2),(16,'service_item_type','16','whoami',1576673868,1576674502,2),(17,'service_item_type','17','whoami',1576673954,1576674535,2),(18,'service_item_type','18','whoami',1576673991,1576674548,2),(19,'service_item_type','19','whoami',1576674061,1576674567,2),(20,'service_item_type','20','whoami',1576674105,1576674582,2),(21,'service_item_type','21','whoami',1576674135,1576674596,2),(22,'service_item_type','22','whoami',1576674174,1576674609,2),(23,'service_item_type','23','whoami',1576674277,1576674622,2),(24,'service_item_type','24','whoami',1576674300,1576674635,2),(25,'service_item_type','25','whoami',1576674328,1576674648,2),(26,'service_item_type','26','whoami',1576674367,1576674367,2),(27,'service_item_type','27','whoami',1576674684,1576674684,2),(28,'service_item_type','28','whoami',1576674705,1576674705,2),(29,'service_item_type','29','whoami',1576674735,1576674735,2),(30,'service_item_type','30','whoami',1576674758,1576674881,2),(31,'service_item_type','31','whoami',1576674856,1576674856,2),(32,'service_item_type','32','whoami',1576674928,1576675095,2),(33,'service_item_type','33','whoami',1576674955,1576674955,2),(34,'service_item_type','34','whoami',1576674982,1576674982,2),(35,'service_item_type','35','whoami',1576675005,1576675005,2),(36,'service_item_type','36','whoami',1576675030,1576675030,2),(37,'service_item_type','37','whoami',1576675083,1576675083,2),(38,'service_item_type','38','whoami',1576675127,1576675127,2),(39,'service_item_type','39','whoami',1576675188,1576675188,2),(40,'service_item_type','40','whoami',1576675220,1576675220,2),(41,'service_item_type','41','whoami',1576675255,1576675255,2),(42,'service_item_type','42','whoami',1576675322,1576675322,2),(43,'service_item_type','43','whoami',1576675352,1576675352,2),(44,'service_item_type','44','whoami',1576675385,1576675385,2),(45,'service_item_type','45','whoami',1576675407,1576675407,2),(46,'service_item_type','46','whoami',1576675430,1576675430,2),(47,'service_item_type','47','whoami',1576675459,1576675459,2),(48,'service_item_type','48','whoami',1576675704,1576675704,2),(49,'service_item_type','49','whoami',1576675752,1576675752,2),(50,'service_item_type','50','whoami',1576675792,1576675792,2),(51,'service_item_type','51','whoami',1576675844,1576675844,2),(52,'service_item_type','52','whoami',1576675888,1576675888,2),(53,'service_item_type','53','whoami',1576675940,1576675940,2),(54,'service_item_type','54','whoami',1576675970,1576675970,2),(55,'service_item_type','55','whoami',1576676002,1576676002,2),(56,'service_item_type','56','whoami',1576676038,1576676086,2),(57,'service_item_type','57','whoami',1576676069,1576676069,2),(58,'service_item_type','58','whoami',1576676117,1576676117,2),(59,'service_item_type','59','whoami',1576676153,1576676153,2),(60,'service_item_type','60','whoami',1576676180,1576676180,2),(61,'service_item_type','61','whoami',1576676216,1576676216,2),(62,'service_item_type','62','whoami',1576676246,1576676246,2),(63,'service_item_type','63','whoami',1576676274,1576676274,2),(64,'application_status','1','whoami',1576676725,1576676725,2),(65,'application_status','2','whoami',1576676739,1576676739,2),(66,'application_status','3','whoami',1576676759,1576676759,2),(67,'application_status','4','whoami',1576676775,1576676775,2),(68,'application_status','5','whoami',1576676793,1576676793,2),(69,'gmt_fleet_register','1','whoami',1580924604,1581331993,2),(70,'year_model','1','whoami',1580924604,1580924604,2),(71,'year_model','2','whoami',1580924604,1580924604,2),(72,'year_model','3','whoami',1580924604,1580924604,2),(73,'year_model','4','whoami',1580924604,1580924604,2),(74,'year_model','5','whoami',1580924604,1580924604,2),(75,'year_model','6','whoami',1580924604,1580924604,2),(76,'year_model','7','whoami',1580924604,1580924604,2),(77,'year_model','8','whoami',1580924604,1580924604,2),(78,'year_model','9','whoami',1580924604,1580924604,2),(79,'year_model','10','whoami',1580924604,1580924604,2),(80,'year_model','11','whoami',1580924604,1580924604,2),(81,'year_model','12','whoami',1580924604,1580924604,2),(82,'year_model','13','whoami',1580924604,1580924604,2),(83,'year_model','14','whoami',1580924604,1580924604,2),(84,'year_model','15','whoami',1580924604,1580924604,2),(85,'year_model','16','whoami',1580924604,1580924604,2),(86,'year_model','17','whoami',1580924604,1580924604,2),(87,'year_model','18','whoami',1580924604,1580924604,2),(88,'year_model','19','whoami',1580924604,1580924604,2),(89,'month','1','whoami',1580924604,1580924604,2),(90,'month','2','whoami',1580924604,1580924604,2),(91,'month','3','whoami',1580924604,1580924604,2),(92,'month','4','whoami',1580924604,1580924604,2),(93,'month','5','whoami',1580924604,1580924604,2),(94,'month','6','whoami',1580924604,1580924604,2),(95,'month','7','whoami',1580924604,1580924604,2),(96,'month','8','whoami',1580924604,1580924604,2),(97,'month','9','whoami',1580924604,1580924604,2),(98,'month','10','whoami',1580924604,1580924604,2),(99,'month','11','whoami',1580924604,1580924604,2),(100,'month','12','whoami',1580924604,1580924604,2),(101,'body_type','1','whoami',1580924604,1580924604,2),(102,'body_type','2','whoami',1580924604,1580924604,2),(103,'body_type','3','whoami',1580924604,1580924604,2),(104,'body_type','4','whoami',1580924604,1580924604,2),(105,'body_type','5','whoami',1580924604,1580924604,2),(106,'body_type','6','whoami',1580924604,1580924604,2),(107,'body_type','7','whoami',1580924604,1580924604,2),(108,'body_type','8','whoami',1580924604,1580924604,2),(109,'body_type','9','whoami',1580924604,1580924604,2),(110,'body_type','10','whoami',1580924604,1580924604,2),(111,'body_type','11','whoami',1580924604,1580924604,2),(112,'body_type','12','whoami',1580924604,1580924604,2),(113,'body_type','13','whoami',1580924604,1580924604,2),(114,'body_type','14','whoami',1580924604,1580924604,2),(115,'body_type','15','whoami',1580924604,1580924604,2),(116,'vehicle_colour','1','whoami',1580924604,1580924604,2),(117,'vehicle_colour','2','whoami',1580924604,1580924604,2),(118,'vehicle_colour','3','whoami',1580924604,1580924604,2),(119,'vehicle_colour','4','whoami',1580924604,1580924604,2),(120,'vehicle_colour','5','whoami',1580924604,1580924604,2),(121,'vehicle_colour','6','whoami',1580924604,1580924604,2),(122,'vehicle_colour','7','whoami',1580924604,1580924604,2),(123,'vehicle_colour','8','whoami',1580924604,1580924604,2),(124,'vehicle_colour','9','whoami',1580924604,1580924604,2),(125,'vehicle_colour','10','whoami',1580924604,1580924604,2),(126,'vehicle_colour','11','whoami',1580924604,1580924604,2),(127,'vehicle_colour','12','whoami',1580924604,1580924604,2),(128,'vehicle_colour','13','whoami',1580924604,1580924604,2),(129,'vehicle_colour','14','whoami',1580924604,1580924604,2),(130,'vehicle_colour','15','whoami',1580924604,1580924604,2),(131,'vehicle_colour','16','whoami',1580924604,1580924604,2),(132,'vehicle_colour','17','whoami',1580924604,1580924604,2),(133,'vehicle_colour','18','whoami',1580924604,1580924604,2),(134,'vehicle_colour','19','whoami',1580924604,1580924604,2),(135,'vehicle_colour','20','whoami',1580924604,1580924604,2),(136,'vehicle_colour','21','whoami',1580924604,1580924604,2),(137,'vehicle_colour','22','whoami',1580924604,1580924604,2),(138,'vehicle_colour','23','whoami',1580924604,1580924604,2),(139,'vehicle_colour','24','whoami',1580924604,1580924604,2),(140,'vehicle_colour','25','whoami',1580924604,1580924604,2),(141,'vehicle_colour','26','whoami',1580924604,1580924604,2),(142,'vehicle_colour','27','whoami',1580924604,1580924604,2),(143,'vehicle_colour','28','whoami',1580924604,1580924604,2),(144,'province','1','whoami',1580924605,1580924605,2),(145,'province','2','whoami',1580924605,1580924605,2),(146,'province','3','whoami',1580924605,1580924605,2),(147,'province','4','whoami',1580924605,1580924605,2),(148,'province','5','whoami',1580924605,1580924605,2),(149,'province','6','whoami',1580924605,1580924605,2),(150,'province','7','whoami',1580924605,1580924605,2),(151,'province','8','whoami',1580924605,1580924605,2),(152,'province','9','whoami',1580924605,1580924605,2),(153,'departments','1','whoami',1580924605,1580924605,2),(154,'departments','2','whoami',1580924605,1580924605,2),(155,'departments','3','whoami',1580924605,1580924605,2),(156,'departments','4','whoami',1580924605,1580924605,2),(157,'departments','5','whoami',1580924605,1580924605,2),(158,'departments','6','whoami',1580924605,1580924605,2),(159,'departments','7','whoami',1580924605,1580924605,2),(160,'departments','8','whoami',1580924605,1580924605,2),(161,'departments','9','whoami',1580924605,1580924605,2),(162,'departments','10','whoami',1580924605,1580924605,2),(163,'departments','11','whoami',1580924605,1580924605,2),(164,'departments','12','whoami',1580924605,1580924605,2),(165,'districts','1','whoami',1580924605,1583057476,2),(166,'districts','2','whoami',1580924605,1583057494,2),(167,'districts','3','whoami',1580924605,1583057509,2),(168,'districts','4','whoami',1580924605,1583057526,2),(169,'districts','5','whoami',1580924605,1583057541,2),(170,'districts','6','whoami',1580924605,1583057754,2),(171,'districts','9','whoami',1580924605,1583057558,2),(172,'districts','10','whoami',1580924605,1583057573,2),(173,'districts','13','whoami',1580924605,1583057589,2),(174,'districts','14','whoami',1580924605,1583057604,2),(175,'districts','15','whoami',1580924605,1583057620,2),(176,'districts','16','whoami',1580924605,1583057640,2),(177,'districts','17','whoami',1580924605,1583057655,2),(178,'districts','18','whoami',1580924605,1583057677,2),(179,'districts','22','whoami',1580924605,1583057743,2),(180,'districts','24','whoami',1580924605,1583057700,2),(181,'districts','26','whoami',1580924605,1583057716,2),(182,'districts','27','whoami',1580924605,1583057769,2),(183,'districts','28','whoami',1580924605,1583057785,2),(184,'districts','32','whoami',1580924605,1583057800,2),(185,'districts','34','whoami',1580924605,1583057815,2),(186,'districts','35','whoami',1580924605,1583057830,2),(187,'districts','37','whoami',1580924605,1583057847,2),(188,'districts','38','whoami',1580924605,1583057862,2),(189,'districts','39','whoami',1580924605,1583057884,2),(190,'districts','40','whoami',1580924605,1583057901,2),(191,'districts','41','whoami',1580924605,1583057915,2),(192,'districts','42','whoami',1580924605,1583057931,2),(193,'districts','43','whoami',1580924605,1583057945,2),(194,'districts','45','whoami',1580924605,1583057960,2),(195,'districts','46','whoami',1580924605,1583057976,2),(196,'districts','50','whoami',1580924605,1583057992,2),(197,'districts','51','whoami',1580924605,1583058004,2),(198,'districts','52','whoami',1580924605,1583058017,2),(199,'districts','55','whoami',1580924605,1583058031,2),(200,'districts','58','whoami',1580924605,1583058047,2),(201,'districts','63','whoami',1580924605,1583058069,2),(202,'districts','67','whoami',1580924605,1583058083,2),(203,'districts','70','whoami',1580924605,1583058098,2),(204,'districts','71','whoami',1580924605,1583058112,2),(205,'districts','79','whoami',1580924605,1583058127,2),(206,'districts','82','whoami',1580924605,1583058143,2),(207,'districts','86','whoami',1580924605,1583058159,2),(208,'districts','87','whoami',1580924605,1583058613,2),(209,'districts','88','whoami',1580924605,1583058627,2),(210,'districts','91','whoami',1580924605,1583058643,2),(211,'districts','94','whoami',1580924605,1583058658,2),(212,'districts','98','whoami',1580924605,1583058673,2),(213,'districts','99','whoami',1580924605,1583058687,2),(214,'districts','105','whoami',1580924605,1583058708,2),(215,'districts','106','whoami',1580924605,1580924605,2),(216,'districts','107','whoami',1580924605,1580924605,2),(217,'districts','108','whoami',1580924605,1580924605,2),(218,'districts','109','whoami',1580924605,1580924605,2),(219,'districts','110','whoami',1580924605,1580924605,2),(220,'districts','111','whoami',1580924605,1580924605,2),(221,'districts','112','whoami',1580924605,1580924605,2),(222,'districts','113','whoami',1580924605,1580924605,2),(223,'districts','114','whoami',1580924605,1580924605,2),(224,'districts','115','whoami',1580924605,1580924605,2),(225,'districts','116','whoami',1580924605,1580924605,2),(226,'districts','117','whoami',1580924605,1580924605,2),(227,'districts','118','whoami',1580924605,1580924605,2),(228,'authorizations','1','whoami',1580924605,1580924605,2),(229,'service_categories','1','whoami',1580924605,1580924605,2),(230,'service_categories','2','whoami',1580924605,1580924605,2),(231,'service_categories','3','whoami',1580924605,1580924605,2),(232,'service_categories','4','whoami',1580924605,1580924605,2),(233,'service_categories','5','whoami',1580924605,1580924605,2),(234,'service_item','1','whoami',1580924605,1580924605,2),(235,'service_item','2','whoami',1580924605,1580924605,2),(236,'service_item','3','whoami',1580924605,1580924605,2),(237,'service_item','4','whoami',1580924605,1580924605,2),(238,'service_item','5','whoami',1580924605,1580924605,2),(239,'purchase_orders','1','whoami',1580924605,1583077341,2),(240,'transmission','1','whoami',1580924605,1580924605,2),(241,'transmission','2','whoami',1580924605,1580924605,2),(242,'transmission','3','whoami',1580924605,1580924605,2),(243,'fuel_type','1','whoami',1580924605,1580924605,2),(244,'fuel_type','2','whoami',1580924605,1580924605,2),(245,'fuel_type','3','whoami',1580924605,1580924605,2),(246,'fuel_type','4','whoami',1580924605,1580924605,2),(247,'fuel_type','5','whoami',1580924605,1580924605,2),(248,'fuel_type','6','whoami',1580924605,1580924605,2),(249,'fuel_type','7','whoami',1580924605,1580924605,2),(250,'fuel_type','8','whoami',1580924605,1580924605,2),(251,'merchant','1','whoami',1580924605,1580924605,2),(252,'merchant_type','1','whoami',1580924605,1580924605,2),(253,'merchant_type','2','whoami',1580924605,1580924605,2),(254,'manufacturer','2','whoami',1580924605,1580924605,2),(255,'manufacturer','3','whoami',1580924605,1583071959,2),(256,'manufacturer','4','whoami',1580924605,1583071750,2),(257,'manufacturer','1','whoami',1580924605,1580924605,2),(258,'manufacturer_type','1','whoami',1580924605,1580924605,2),(259,'manufacturer_type','2','whoami',1580924605,1580924605,2),(260,'manufacturer_type','3','whoami',1580924605,1580924605,2),(261,'manufacturer_type','4','whoami',1580924605,1580924605,2),(262,'driver','1','whoami',1580924605,1583671408,2),(263,'claim_status','1','whoami',1580924605,1580924605,2),(264,'claim_status','2','whoami',1580924605,1580924605,2),(265,'claim_status','3','whoami',1580924605,1580924605,2),(266,'claim_status','4','whoami',1580924605,1580924605,2),(267,'claim_category','1','whoami',1580924605,1580924605,2),(268,'claim_category','2','whoami',1580924605,1580924605,2),(269,'claim_category','3','whoami',1580924605,1580924605,2),(270,'claim_category','4','whoami',1580924605,1580924605,2),(271,'claim_category','5','whoami',1580924605,1580924605,2),(272,'cost_centre','1','whoami',1580924605,1580924605,2),(273,'dealer','1','whoami',1580924606,1580981212,2),(274,'dealer','2','whoami',1580924606,1580981227,2),(275,'dealer','3','whoami',1580924606,1580981240,2),(276,'dealer','4','whoami',1580924606,1580981254,2),(277,'dealer','5','whoami',1580924606,1580981270,2),(278,'dealer','6','whoami',1580924606,1580981284,2),(279,'dealer','7','whoami',1580924606,1580981299,2),(280,'dealer_type','1','whoami',1580924606,1580924606,2),(281,'dealer_type','2','whoami',1580924606,1580924606,2),(282,'dealer_type','3','whoami',1580924606,1580924606,2),(283,'vehicle_daily_check_list','1','whoami',1580924606,1580924606,2),(284,'forms','1','whoami',1580994723,1581010961,2),(285,'log_sheet','1','whoami',1581339021,1581339177,2),(286,'parts','1','whoami',1581857874,1583071990,2),(287,'claim','1','whoami',1581881032,1581881032,2),(288,'parts_type','1','whoami',1582814929,1582814929,2),(289,'parts_type','2','whoami',1582814944,1582814944,2),(290,'parts_type','3','whoami',1582814966,1582814966,2),(291,'parts_type','4','whoami',1582814982,1582814982,2),(292,'parts_type','5','whoami',1582815007,1582815007,2),(293,'service_schedule','1','whoami',1583046012,1583069175,2),(294,'reception','1','whoami',1583049361,1583049360,2),(295,'breakdown_services','1','whoami',1583063167,1583075434,2),(296,'manufacturer_type','5','whoami',1583071629,1583071629,2),(297,'manufacturer_type','6','whoami',1583071843,1583071843,2),(298,'manufacturer','5','whoami',1583071892,1583071892,2),(299,'service_provider_type','1','whoami',1584020811,1584020811,2),(300,'vehicle_history','1','whoami',1584026533,1584026533,2),(301,'work_allocation','1','whoami',1584026692,1584602375,2);
/*!40000 ALTER TABLE `membership_userrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `membership_userrecords` with 301 row(s)
--

--
-- Table structure for table `membership_users`
--

DROP TABLE IF EXISTS `membership_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_users` (
  `memberID` varchar(100) NOT NULL,
  `passMD5` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) unsigned DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text,
  `custom2` text,
  `custom3` text,
  `custom4` text,
  `comments` text,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) unsigned DEFAULT NULL,
  `flags` text,
  PRIMARY KEY (`memberID`),
  KEY `groupID` (`groupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_users`
--

LOCK TABLES `membership_users` WRITE;
/*!40000 ALTER TABLE `membership_users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `membership_users` VALUES ('12345678','87d026dbf8a43d90292525d3962348a4','masogam@dot.limpopo.gov.za','2015-05-29',11,0,1,'Masoga Mosima','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('80066241','eb553780cbf79034aec1f5fb40578592','mathebulax@dot.limpopo.gov.za','2015-05-29',11,0,1,'Mathebula Xirhandziwa','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('80188729','5ef1aa132d29be4ffa38c7ce7f6795c2','nekhumbee@dot.limpopo.gov.za','2015-05-29',11,0,1,'Nekhumbe Eric','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('80189628','97e28887bcea83e8689968fdb0d8b5f4','rembuluwanib@dot.limpopo.gov.za','2015-05-29',11,0,1,'Rembuluwani Botha','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('80206123','94cea4b68bf2bb033088c3573fe50fdd','tholes@dot.limpopo.gov.za','2015-05-29',11,0,1,'Thole Seete Solomon','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('80206247','1e48448554e5f112b0a20d3dcef07047','moloper@dot.limpopo.gov.za','2015-05-29',11,0,1,'Raisibe Molope','Phamoko Towers , LDoT Head Office','Polokwane','Limpopo','',NULL,NULL,NULL),('80206701','ec7a485a1de197269f2731565a43462b','senthumulet@dot.limpopo.gov.za','2015-05-29',11,0,1,'Tebogo Senthumule','Phamoko Towers , LDoT Head Office','Polokwane','Limpopo','',NULL,NULL,NULL),('80206751','519b032082b7189017ac4fb082dbe2cf','phaahlae@dot.limpopo.gov.za','2015-05-29',11,0,1,'Phaahla Edith Madipoane','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('8020722','4e2e2bb844b91a90287858b7a2ec5ebb','selolom@dot.limpopo.gov.za','2015-05-29',11,0,1,'Manare Selolo','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('80207456','1bebd7682720c07f5aa77cc6e1074b03','ribaj@dot.limpopo.gov.za','2015-05-29',2,0,1,'Joseph Riba','40 Pres Paul Kruger str, Phamaoko Towers','Polokwane','Limpopo','',NULL,NULL,NULL),('80207880','e9a93a1f48a4fb487ffd2bd5d57ca63f','thobejanem@dot.limpopo.gov.za','2016-05-05',2,0,1,'Matsobane Matthews Thobejane','40 Pres Paul Kruger street, Phamako Towers','Polokwane','Limpopo','',NULL,NULL,NULL),('80258433','df37d9686b81bfb549bdcfb5ca8eddea','mashilat@dot.limpopo.gov.za','2015-05-29',11,0,1,'Mashila Thomas','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('81071558','533341599be361c14bde827b7b593193','mabundzak@dot.limpopo.gov.za','2015-05-29',11,0,1,'Mabundza Kufeni Section','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('81292571','33803cdf662ae653820c4b7200272202','mashothlap@dot.limpopo.gov.za','2015-05-29',11,0,1,'Mashothla Phorabatho','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('81971460','1433e639a12d7c69bb88345103186705','mphaphulir@dot.limpopo.gov.za','2015-05-29',2,0,1,'Reggy Mphaphuli','LDoT, Phamoko Towers,C/o Church Str 39 & Bodenstein Str','Polokwane','Limpopo','Capture history details of auctioned vehicles',NULL,NULL,NULL),('82414181','33ee226991c5025c6b0721835f539b47','mogodim@dot.limpopo.gov.za','2015-05-29',11,0,1,'Nancy Mogodi','39 Pres Paul Kruger str, Phamaoko Towers','Polokwane','Limpopo','',NULL,NULL,NULL),('82504741','cfcf7dc78d4c7b245fa867e047d85cbf','mookam@dot.limpopo.gov.za','2015-05-29',2,0,1,'Marcus Mooka','40 Pres Paul Krugers str, Phamoko Towers,','Polokwane','Limpopo','',NULL,NULL,NULL),('84216123','f32866f0e5aa5c8d2ecfe156de152f4a','mabalaj@dot.limpopo.gov.za','2017-11-14',2,0,1,'J Mabala','40 Pres Paul Kruger street','Polokwane','Limpopo','',NULL,NULL,NULL),('guest',NULL,NULL,'2019-12-17',1,0,1,NULL,NULL,NULL,NULL,'Anonymous member created automatically on 2019-12-17',NULL,NULL,NULL),('mahlatse','$2y$10$zO620.1Lw3V5jB.kJCndRuunfF2fkzmy2MSvRGg7Zj8XE/Jv2MMri','mm.mogowe@gmail.com','2020-03-18',2,0,1,'Mahlatse Mogowe','','','','',NULL,NULL,NULL),('whoami','$2y$10$q8Nvm7sMeHOIUD76fZBiWukxnULcu8hwnRfDkSFOmU6GbllVvSBaa','krielm@dtcs.limpopo.gov.za','2019-12-17',2,0,1,NULL,NULL,NULL,NULL,'Admin member created automatically on 2019-12-17\nRecord updated automatically on 2020-02-05\nRecord updated automatically on 2020-02-17\nRecord updated automatically on 2020-03-01\nRecord updated automatically on 2020-03-18\nRecord updated automatically on 2020-03-18\nRecord updated automatically on 2020-03-18\nRecord updated automatically on 2020-03-18',NULL,NULL,NULL);
/*!40000 ALTER TABLE `membership_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `membership_users` with 21 row(s)
--

--
-- Table structure for table `membership_usersessions`
--

DROP TABLE IF EXISTS `membership_usersessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_usersessions` (
  `memberID` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL,
  `agent` varchar(100) NOT NULL,
  `expiry_ts` int(10) unsigned NOT NULL,
  UNIQUE KEY `memberID_token_agent` (`memberID`,`token`,`agent`),
  KEY `memberID` (`memberID`),
  KEY `expiry_ts` (`expiry_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_usersessions`
--

LOCK TABLES `membership_usersessions` WRITE;
/*!40000 ALTER TABLE `membership_usersessions` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `membership_usersessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `membership_usersessions` with 0 row(s)
--

--
-- Table structure for table `merchant`
--

DROP TABLE IF EXISTS `merchant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchant` (
  `merchant_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_type` int(11) DEFAULT NULL,
  `merchant_code` varchar(40) DEFAULT NULL,
  `merchant_name` varchar(40) DEFAULT NULL,
  `merchant_contact_email` varchar(40) DEFAULT NULL,
  `merchant_street_address` text,
  `merchant_suburb` varchar(40) DEFAULT NULL,
  `merchant_city` varchar(40) DEFAULT NULL,
  `merchant_address_code` varchar(40) DEFAULT NULL,
  `merchant_contact_details` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`merchant_id`),
  KEY `merchant_type` (`merchant_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant`
--

LOCK TABLES `merchant` WRITE;
/*!40000 ALTER TABLE `merchant` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `merchant` VALUES (1,2,'18871283','GEARBOX & DIFF','geaboxndiff@mweb.co.za','15 NATRIUM ST&nbsp;&nbsp;&nbsp; <br>','LADINE','PIETERSBURG','0699','0152930595');
/*!40000 ALTER TABLE `merchant` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `merchant` with 1 row(s)
--

--
-- Table structure for table `merchant_type`
--

DROP TABLE IF EXISTS `merchant_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchant_type` (
  `merchant_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`merchant_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant_type`
--

LOCK TABLES `merchant_type` WRITE;
/*!40000 ALTER TABLE `merchant_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `merchant_type` VALUES (1,'Wholesale'),(2,'Retail');
/*!40000 ALTER TABLE `merchant_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `merchant_type` with 2 row(s)
--

--
-- Table structure for table `modification_to_vehicle`
--

DROP TABLE IF EXISTS `modification_to_vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modification_to_vehicle` (
  `modification_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_vehicle` int(11) DEFAULT NULL,
  `directorate` varchar(40) DEFAULT NULL,
  `head_office` varchar(40) DEFAULT NULL,
  `districts` int(11) DEFAULT NULL,
  `drivers_name_and_surname` int(11) DEFAULT NULL,
  `drivers_persal_number` int(11) NOT NULL,
  `drivers_contact_details` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `model_of_vehicle` int(11) DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `objective` text,
  `designation` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `cellphone_number` varchar(40) DEFAULT NULL,
  `fuel_gauge_amount` varchar(40) DEFAULT NULL,
  `keys_ignition` varchar(40) DEFAULT NULL,
  `petrol_cap_with_keys` varchar(40) DEFAULT NULL,
  `padlock_with_keys` varchar(40) DEFAULT NULL,
  `tyre_r_f` varchar(40) DEFAULT NULL,
  `tyre_r_f_1` varchar(40) DEFAULT NULL,
  `tyre_r_r` varchar(40) DEFAULT NULL,
  `tyre_r_r_1` varchar(40) DEFAULT NULL,
  `tyre_l_f` varchar(40) DEFAULT NULL,
  `tyre_l_f_1` varchar(40) DEFAULT NULL,
  `tyer_l_r` varchar(40) DEFAULT NULL,
  `tyer_l_r_1` varchar(40) DEFAULT NULL,
  `tyre_spare` varchar(40) DEFAULT NULL,
  `tyre_spare_1` varchar(40) DEFAULT NULL,
  `wheel_cups` text,
  `other` text,
  `battery` varchar(40) DEFAULT NULL,
  `battery_voltage` varchar(40) DEFAULT NULL,
  `wheel_spanner` varchar(40) DEFAULT NULL,
  `jack_with_handle` varchar(40) DEFAULT NULL,
  `radio_dvd_combination` varchar(40) DEFAULT NULL,
  `petrol_card` varchar(40) DEFAULT NULL,
  `valid_license_disc` varchar(40) DEFAULT NULL,
  `valid_license_disc_date` date DEFAULT NULL,
  `fire_extinguisher` varchar(40) DEFAULT NULL,
  `warning_signs_traingle` text,
  `driver_name` varchar(40) DEFAULT NULL,
  `driver_surname` varchar(40) DEFAULT NULL,
  `driver_persal_number` varchar(40) DEFAULT NULL,
  `driver_rank` varchar(40) DEFAULT NULL,
  `driver_signature` varchar(40) DEFAULT NULL,
  `date_checked_in` datetime DEFAULT '2020-01-01 00:00:00',
  `testing_officer_name_and_surname` varchar(40) DEFAULT NULL,
  `testing_officer_persal_number` varchar(40) DEFAULT NULL,
  `testing_officer_rank` varchar(40) DEFAULT NULL,
  `testing_officer_signature` varchar(40) DEFAULT NULL,
  `date_received` datetime DEFAULT '2020-01-01 00:00:00',
  `supervisor_for_allocation_name_and_surname` varchar(40) DEFAULT NULL,
  `supervisor_for_allocation_persal_number` varchar(40) DEFAULT NULL,
  `supervisor_for_allocation_rank` varchar(40) DEFAULT NULL,
  `supervisor_for_allocation_signature` varchar(40) DEFAULT NULL,
  `driver_name_and_surname1` varchar(40) DEFAULT NULL,
  `driver_persal_number_1` varchar(40) DEFAULT NULL,
  `driver_rank_1` varchar(40) DEFAULT NULL,
  `driver_signature_1` varchar(40) DEFAULT NULL,
  `date_checked_in_1` datetime DEFAULT '2020-01-01 00:00:00',
  PRIMARY KEY (`modification_id`),
  KEY `type_of_vehicle` (`type_of_vehicle`),
  KEY `districts` (`districts`),
  KEY `drivers_name` (`drivers_name_and_surname`),
  KEY `drivers_contact_details` (`drivers_contact_details`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `job_card_number` (`job_card_number`),
  KEY `closing_km` (`closing_km`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modification_to_vehicle`
--

LOCK TABLES `modification_to_vehicle` WRITE;
/*!40000 ALTER TABLE `modification_to_vehicle` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `modification_to_vehicle` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `modification_to_vehicle` with 0 row(s)
--

--
-- Table structure for table `month`
--

DROP TABLE IF EXISTS `month`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `month` (
  `month_id` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`month_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `month`
--

LOCK TABLES `month` WRITE;
/*!40000 ALTER TABLE `month` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `month` VALUES (1,'January'),(2,'February'),(3,'March'),(4,'April'),(5,'May'),(6,'June'),(7,'July'),(8,'August'),(9,'September'),(10,'October'),(11,'November'),(12,'December');
/*!40000 ALTER TABLE `month` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `month` with 12 row(s)
--

--
-- Table structure for table `movement_of_personnel_in_government_garage_and_workshops`
--

DROP TABLE IF EXISTS `movement_of_personnel_in_government_garage_and_workshops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movement_of_personnel_in_government_garage_and_workshops` (
  `movement_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_inspection` int(11) DEFAULT NULL,
  `vehicle_model` varchar(40) DEFAULT NULL,
  `vehicle_number_plate` varchar(40) DEFAULT NULL,
  `vehicle_tires_check` varchar(40) DEFAULT NULL,
  `vehicle_mirrow_check` varchar(40) DEFAULT NULL,
  `gate_security_signature` varchar(40) DEFAULT NULL,
  `government_garage_protocol` varchar(40) DEFAULT NULL,
  `government_garage_safety` varchar(40) DEFAULT NULL,
  `vehicle_handing_over_checklist` varchar(40) DEFAULT NULL,
  `vehicle_return_list` varchar(40) DEFAULT NULL,
  `approved_workshop_procedure_manual` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` varchar(25) DEFAULT NULL,
  `engine_number` varchar(35) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  PRIMARY KEY (`movement_id`),
  KEY `vehicle_inspection` (`vehicle_inspection`),
  KEY `make_of_vehicle` (`make_of_vehicle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movement_of_personnel_in_government_garage_and_workshops`
--

LOCK TABLES `movement_of_personnel_in_government_garage_and_workshops` WRITE;
/*!40000 ALTER TABLE `movement_of_personnel_in_government_garage_and_workshops` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `movement_of_personnel_in_government_garage_and_workshops` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `movement_of_personnel_in_government_garage_and_workshops` with 0 row(s)
--

--
-- Table structure for table `ordering_of_spares_for_internal_repairs`
--

DROP TABLE IF EXISTS `ordering_of_spares_for_internal_repairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordering_of_spares_for_internal_repairs` (
  `spares_id` int(11) NOT NULL AUTO_INCREMENT,
  `artisan_name_and_surname` varchar(40) DEFAULT NULL,
  `artisan_contacts` varchar(40) DEFAULT NULL,
  `artisan_email_address` varchar(40) DEFAULT NULL,
  `artisan_signature` varchar(40) DEFAULT NULL,
  `part_type_8` int(11) DEFAULT NULL,
  `part_name_8` int(11) DEFAULT NULL,
  `description_8` int(11) DEFAULT NULL,
  `manufacture_8` int(11) DEFAULT NULL,
  `quality_8` varchar(40) DEFAULT NULL,
  `net_part_price_8` decimal(10,2) DEFAULT '0.00',
  `tax` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `supervisor_name_and_surname` varchar(40) DEFAULT NULL,
  `supervisor_contact_details` varchar(40) DEFAULT NULL,
  `supervisor_email_address` varchar(40) DEFAULT NULL,
  `supervisor_signature` varchar(40) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  `date_parts_ordered` datetime DEFAULT NULL,
  `date_parts_received` datetime DEFAULT NULL,
  `workshop_manager_name_and_surname` varchar(40) DEFAULT NULL,
  `workshop_manager_contact_details` varchar(40) DEFAULT NULL,
  `workshop_manager_email_address` varchar(40) DEFAULT NULL,
  `workshop_manager_signature` varchar(40) DEFAULT NULL,
  `internal_requisition_to_stores_approved` varchar(40) DEFAULT NULL,
  `internal_requisition_to_stores` varchar(40) DEFAULT NULL,
  `internal_requisition_to_stores_recommended` varchar(40) DEFAULT NULL,
  `attached_requisition_form` varchar(40) DEFAULT NULL,
  `part_type_2` int(11) DEFAULT NULL,
  `part_type_3` int(11) DEFAULT NULL,
  `part_type_4` int(11) DEFAULT NULL,
  `part_type_5` int(11) DEFAULT NULL,
  `part_type_6` int(11) DEFAULT NULL,
  `part_type_7` int(11) DEFAULT NULL,
  `part_name_1` int(11) DEFAULT NULL,
  `part_name_2` int(11) DEFAULT NULL,
  `part_name_3` int(11) DEFAULT NULL,
  `part_name_4` int(11) DEFAULT NULL,
  `part_name_5` int(11) DEFAULT NULL,
  `part_name_6` int(11) DEFAULT NULL,
  `part_name_7` int(11) DEFAULT NULL,
  `description_1` int(11) DEFAULT NULL,
  `description_2` int(11) DEFAULT NULL,
  `description_3` int(11) DEFAULT NULL,
  `description_4` int(11) DEFAULT NULL,
  `description_5` int(11) DEFAULT NULL,
  `description_6` int(11) DEFAULT NULL,
  `description_7` int(11) DEFAULT NULL,
  `manufacture_1` int(11) DEFAULT NULL,
  `manufacture_2` int(11) DEFAULT NULL,
  `manufacture_3` int(11) DEFAULT NULL,
  `manufacture_4` int(11) DEFAULT NULL,
  `manufacture_5` int(11) DEFAULT NULL,
  `manufacture_6` int(11) DEFAULT NULL,
  `manufacture_7` int(11) DEFAULT NULL,
  `quality_1` varchar(40) DEFAULT NULL,
  `quality_2` varchar(40) DEFAULT NULL,
  `quality_3` varchar(40) DEFAULT NULL,
  `quality_4` varchar(40) DEFAULT NULL,
  `quality_5` varchar(40) DEFAULT NULL,
  `quality_6` varchar(40) DEFAULT NULL,
  `quality_7` varchar(40) DEFAULT NULL,
  `unit_price_1` decimal(10,2) DEFAULT '0.00',
  `unit_price_2` decimal(10,2) DEFAULT '0.00',
  `unit_price_3` decimal(10,2) DEFAULT '0.00',
  `unit_price_4` decimal(10,2) DEFAULT '0.00',
  `unit_price_5` decimal(10,2) DEFAULT '0.00',
  `unit_price_6` decimal(10,2) DEFAULT '0.00',
  `unit_price_7` decimal(10,2) DEFAULT '0.00',
  `field33` varchar(40) DEFAULT NULL,
  `net_part_price_1` decimal(10,2) DEFAULT '0.00',
  `net_part_price_2` decimal(10,2) DEFAULT '0.00',
  `net_part_price_3` decimal(10,2) DEFAULT '0.00',
  `net_part_price_4` decimal(10,2) DEFAULT '0.00',
  `net_part_price_5` decimal(10,2) DEFAULT '0.00',
  `net_part_price_6` decimal(10,2) DEFAULT '0.00',
  `net_part_price_7` decimal(10,2) DEFAULT '0.00',
  `workshop_name` int(11) DEFAULT NULL,
  `unit_price_8` decimal(10,2) DEFAULT '0.00',
  `part_type_1` int(11) DEFAULT NULL,
  PRIMARY KEY (`spares_id`),
  KEY `part_type` (`part_type_8`),
  KEY `part_name` (`part_name_8`),
  KEY `manufacture` (`manufacture_8`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `description` (`description_8`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`),
  KEY `workshop_name` (`workshop_name`),
  KEY `part_name_1` (`part_name_1`),
  KEY `description_1` (`description_1`),
  KEY `manufacture_1` (`manufacture_1`),
  KEY `part_type_2` (`part_type_2`),
  KEY `part_name_2` (`part_name_2`),
  KEY `description_2` (`description_2`),
  KEY `manufacture_2` (`manufacture_2`),
  KEY `part_type_3` (`part_type_3`),
  KEY `part_name_3` (`part_name_3`),
  KEY `description_3` (`description_3`),
  KEY `manufacture_3` (`manufacture_3`),
  KEY `part_type_4` (`part_type_4`),
  KEY `part_name_4` (`part_name_4`),
  KEY `description_4` (`description_4`),
  KEY `manufacture_4` (`manufacture_4`),
  KEY `part_type_5` (`part_type_5`),
  KEY `part_name_5` (`part_name_5`),
  KEY `description_5` (`description_5`),
  KEY `manufacture_5` (`manufacture_5`),
  KEY `part_type_6` (`part_type_6`),
  KEY `part_name_6` (`part_name_6`),
  KEY `description_6` (`description_6`),
  KEY `manufacture_6` (`manufacture_6`),
  KEY `part_type_7` (`part_type_7`),
  KEY `part_name_7` (`part_name_7`),
  KEY `description_7` (`description_7`),
  KEY `manufacture_7` (`manufacture_7`),
  KEY `part_type_1` (`part_type_1`),
  KEY `job_card_number` (`job_card_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordering_of_spares_for_internal_repairs`
--

LOCK TABLES `ordering_of_spares_for_internal_repairs` WRITE;
/*!40000 ALTER TABLE `ordering_of_spares_for_internal_repairs` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `ordering_of_spares_for_internal_repairs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `ordering_of_spares_for_internal_repairs` with 0 row(s)
--

--
-- Table structure for table `parts`
--

DROP TABLE IF EXISTS `parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts` (
  `parts_id` int(11) NOT NULL AUTO_INCREMENT,
  `part_type` int(11) DEFAULT NULL,
  `part_number` varchar(40) DEFAULT NULL,
  `part_name` varchar(40) DEFAULT NULL,
  `description` text,
  `manufacturer` int(11) DEFAULT NULL,
  `dealer` int(11) DEFAULT NULL,
  `measure` varchar(40) DEFAULT NULL,
  `net_part_price` decimal(10,2) DEFAULT '0.00',
  `unit_price` decimal(10,2) DEFAULT '0.00',
  `quantity` varchar(40) DEFAULT NULL,
  `freight` varchar(40) DEFAULT NULL,
  `tax` varchar(40) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT '0.00',
  `discount_price` decimal(10,2) DEFAULT '0.00',
  `total_amount` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`parts_id`),
  KEY `part_type` (`part_type`),
  KEY `manufacturer` (`manufacturer`),
  KEY `dealer` (`dealer`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts`
--

LOCK TABLES `parts` WRITE;
/*!40000 ALTER TABLE `parts` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `parts` VALUES (1,3,'AF-SUV-T-Rav4-2020-02-27','Air Filter SUV Toyota Rav 4 G.X 2.0','Air Filter SUV Toyota Rav 4 <br>',5,1,'PC',113.48,35.50,'2','50.00','0.15',121.00,25.67,18.15);
/*!40000 ALTER TABLE `parts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `parts` with 1 row(s)
--

--
-- Table structure for table `parts_type`
--

DROP TABLE IF EXISTS `parts_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts_type` (
  `part_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `part_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`part_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts_type`
--

LOCK TABLES `parts_type` WRITE;
/*!40000 ALTER TABLE `parts_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `parts_type` VALUES (1,'Bearing'),(2,'Gasket'),(3,'Air Filter'),(4,'Oil Filter'),(5,'Brake pads');
/*!40000 ALTER TABLE `parts_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `parts_type` with 5 row(s)
--

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `province` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `province` VALUES (1,'Limpopo'),(2,'Mpumalanga'),(3,'North West'),(4,'Gauteng'),(5,'Free State'),(6,'KwaZulu-Natal'),(7,'Eastern Cape'),(8,'Northern Cape'),(9,'Western Cape');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `province` with 9 row(s)
--

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_orders` (
  `purchase_order_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchased_order_number` varchar(40) NOT NULL,
  `purchased_date` date DEFAULT NULL,
  `purchaser` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `type_of_vehicle` int(6) DEFAULT NULL,
  `manufacturer` int(11) DEFAULT NULL,
  `service_type` text,
  `service_category` int(11) DEFAULT NULL,
  `service_item` text,
  `upload_quotation` varchar(40) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `merchant_name` int(11) DEFAULT NULL,
  `date_of_service` date DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `labour_category_1` varchar(40) DEFAULT NULL,
  `part_number_1` int(11) DEFAULT NULL,
  `part_name_1` int(11) DEFAULT NULL,
  `part_manufacturer_name_1` int(11) DEFAULT NULL,
  `quantity_1` varchar(40) DEFAULT NULL,
  `expense_of_item_1` decimal(10,2) DEFAULT '0.00',
  `labour_category_2` varchar(40) DEFAULT NULL,
  `part_number_2` int(11) DEFAULT NULL,
  `part_name_2` int(11) DEFAULT NULL,
  `part_manufacturer_name_2` int(11) DEFAULT NULL,
  `quantity_2` varchar(40) DEFAULT NULL,
  `expense_of_item_2` decimal(10,2) DEFAULT '0.00',
  `labour_category_3` varchar(40) DEFAULT NULL,
  `part_number_3` int(11) DEFAULT NULL,
  `part_name_3` int(11) DEFAULT NULL,
  `part_manufacturer_name_3` int(11) DEFAULT NULL,
  `quantity_3` varchar(40) DEFAULT NULL,
  `expense_of_item_3` decimal(10,2) DEFAULT '0.00',
  `labour_category_4` varchar(40) DEFAULT NULL,
  `part_number_4` int(11) DEFAULT NULL,
  `part_name_4` int(11) DEFAULT NULL,
  `part_manufacturer_name_4` int(11) DEFAULT NULL,
  `quantity_4` varchar(40) DEFAULT NULL,
  `expense_of_item_4` decimal(10,2) DEFAULT '0.00',
  `labour_category_5` varchar(40) DEFAULT NULL,
  `part_number_5` int(11) DEFAULT NULL,
  `part_name_5` int(11) DEFAULT NULL,
  `part_manufacturer_name_5` int(11) DEFAULT NULL,
  `quantity_5` varchar(40) DEFAULT NULL,
  `expense_of_item_5` decimal(10,2) DEFAULT '0.00',
  `labour_category_6` varchar(40) DEFAULT NULL,
  `part_number_6` int(11) DEFAULT NULL,
  `part_name_6` int(11) DEFAULT NULL,
  `part_manufacturer_name_6` int(11) DEFAULT NULL,
  `quantity_6` varchar(40) DEFAULT NULL,
  `expense_of_item_6` decimal(10,2) DEFAULT '0.00',
  `labour_category_7` varchar(40) DEFAULT NULL,
  `part_number_7` int(11) DEFAULT NULL,
  `part_name_7` int(11) DEFAULT NULL,
  `part_manufacturer_name_7` int(11) DEFAULT NULL,
  `quantity_7` varchar(40) DEFAULT NULL,
  `expense_of_item_7` decimal(10,2) DEFAULT '0.00',
  `labour_category_8` varchar(40) DEFAULT NULL,
  `part_number_8` int(11) DEFAULT NULL,
  `part_name_8` int(11) DEFAULT NULL,
  `part_manufacturer_name_8` int(11) DEFAULT NULL,
  `expense_of_item_8` decimal(10,2) DEFAULT '0.00',
  `material_cost` decimal(10,2) DEFAULT '0.00',
  `average_worktime_hrs` varchar(40) DEFAULT NULL,
  `standard_labour_cost_per_hour` decimal(10,2) DEFAULT '0.00',
  `labour_charges` decimal(10,2) DEFAULT NULL,
  `vat` decimal(10,2) DEFAULT '0.15',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `work_order_id` int(11) DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `comments` longtext,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `date_captured` date DEFAULT NULL,
  `data_capturer` varchar(40) DEFAULT NULL,
  `data_capturer_contact_email` varchar(40) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`purchase_order_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `manufacturer` (`manufacturer`),
  KEY `service_category` (`service_category`),
  KEY `merchant_name` (`merchant_name`),
  KEY `closing_km` (`closing_km`),
  KEY `part_number_1` (`part_number_1`),
  KEY `part_name_1` (`part_name_1`),
  KEY `part_manufacturer_name_1` (`part_manufacturer_name_1`),
  KEY `part_number_2` (`part_number_2`),
  KEY `part_name_2` (`part_name_2`),
  KEY `part_manufacturer_name_2` (`part_manufacturer_name_2`),
  KEY `part_number_3` (`part_number_3`),
  KEY `part_manufacturer_name_3` (`part_manufacturer_name_3`),
  KEY `part_number_4` (`part_number_4`),
  KEY `part_manufacturer_name_4` (`part_manufacturer_name_4`),
  KEY `part_number_5` (`part_number_5`),
  KEY `part_manufacturer_name_5` (`part_manufacturer_name_5`),
  KEY `part_number_6` (`part_number_6`),
  KEY `part_name_6` (`part_name_6`),
  KEY `part_manufacturer_name_6` (`part_manufacturer_name_6`),
  KEY `part_number_7` (`part_number_7`),
  KEY `part_name_7` (`part_name_7`),
  KEY `part_manufacturer_name_7` (`part_manufacturer_name_7`),
  KEY `part_number_8` (`part_number_8`),
  KEY `part_name_8` (`part_name_8`),
  KEY `part_manufacturer_name_8` (`part_manufacturer_name_8`),
  KEY `workshop_name` (`workshop_name`),
  KEY `work_order_id` (`work_order_id`),
  KEY `job_card_number` (`job_card_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `purchase_orders` VALUES (1,'PO-LDoT-2019/09/11-234567','2019-09-04','Dennis Maja',1,1,1,'Check battery and cables, Check brakes',2,NULL,'Z1a_Leave_-_edited.pdf','2019-11-08',1,'2019-11-06',NULL,'Replace',NULL,NULL,2,'1',783.46,'Replace',NULL,NULL,4,'7',250.00,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,0.00,0.00,NULL,0.00,545.65,0.15,3540.98,1,NULL,'2019-11-08','<br>',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `purchase_orders` with 1 row(s)
--

--
-- Table structure for table `reception`
--

DROP TABLE IF EXISTS `reception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reception` (
  `reception_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `reception_name_and_surname` varchar(40) DEFAULT NULL,
  `reception_persal_number` varchar(40) DEFAULT NULL,
  `reception_contact_details` varchar(40) DEFAULT NULL,
  `reception_email_address` varchar(40) DEFAULT NULL,
  `reception_signature` varchar(40) NOT NULL,
  `breakdown_of_vehicle` varchar(40) DEFAULT NULL,
  `description_of_vehicle_report` text,
  `description_of_vehicle_breakdown` text,
  `job_card_number` varchar(40) DEFAULT NULL,
  `visual_inspection_form` varchar(40) DEFAULT NULL,
  `damage_report` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `workshop_address` text,
  `date_of_vehicle_entrance` datetime DEFAULT NULL,
  `date_of_vehicle_exit` datetime DEFAULT NULL,
  `upload_of_vehicle_report` text,
  `description_of_vehicle_report_1` text,
  PRIMARY KEY (`reception_user_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `workshop_name` (`workshop_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reception`
--

LOCK TABLES `reception` WRITE;
/*!40000 ALTER TABLE `reception` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `reception` VALUES (1,'Queen Khoza','12345678','015 295 1077','khozaq@ldot.gov.za','Queen Khoza','Yes',NULL,NULL,'LDTCS- LebGG/01/03/2020',NULL,NULL,1,1,1,22,'<br>',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `reception` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `reception` with 1 row(s)
--

--
-- Table structure for table `service_categories`
--

DROP TABLE IF EXISTS `service_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_categories` (
  `service_categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`service_categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_categories`
--

LOCK TABLES `service_categories` WRITE;
/*!40000 ALTER TABLE `service_categories` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `service_categories` VALUES (1,'Minor Service'),(2,'Major Service'),(3,'Comprehensive Service'),(4,'Tune Up Service'),(5,'Auto Transmission Service');
/*!40000 ALTER TABLE `service_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_categories` with 5 row(s)
--

--
-- Table structure for table `service_item`
--

DROP TABLE IF EXISTS `service_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_item` (
  `service_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_item` text,
  PRIMARY KEY (`service_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_item`
--

LOCK TABLES `service_item` WRITE;
/*!40000 ALTER TABLE `service_item` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `service_item` VALUES (1,'Change Oil'),(2,'Check Battery and Cables'),(3,'Check Brake Fluid'),(4,'Check Brakes'),(5,'Check Coolant (anti-freeze)');
/*!40000 ALTER TABLE `service_item` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_item` with 5 row(s)
--

--
-- Table structure for table `service_item_type`
--

DROP TABLE IF EXISTS `service_item_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_item_type` (
  `service_item_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_item_type` varchar(40) DEFAULT NULL,
  `service_item_type_code` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`service_item_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_item_type`
--

LOCK TABLES `service_item_type` WRITE;
/*!40000 ALTER TABLE `service_item_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `service_item_type` VALUES (1,'Bodywork - Minor','R001'),(2,'Bodywork - Rust','R002'),(3,'Brake System - Minor','R003'),(4,'Brake System - Overhaul','R004'),(5,'Chassis - Repair','R005'),(6,'Cooling System - Minor','R006'),(7,'Cooling System - Major','R007'),(8,'Clutch - Minor','R008'),(9,'Clutch - Overhaul','R009'),(10,'Differential - Minor','R010'),(11,'Differential - Overhaul','R011'),(12,'Electrical Assesories & Wiring','R012'),(13,'Electrical - Charge','R013'),(14,'Electrical - Ignition','R014'),(15,'Electrical - Starter','R015'),(16,'Engine Minor - Repair','R016'),(17,'Engine - Overhaul','R017'),(18,'Exhaust Minor - Repair','R018'),(19,'Exhaust System - Replacement','R019'),(20,'Fuel System - Repair','R020'),(21,'Fuel System - Replacement','R021'),(22,'Gearbox Minor - Repairs','R022'),(23,'Gearbox - Overhaul','R023'),(24,'Steering Minor - Repairs','R024'),(25,'Steering - Overhaul','R025'),(26,'Suspension - Minor','R026'),(27,'Suspension - Overhaul','R027'),(28,'Upholstery','R028'),(29,'Wheel - Alignment','R029'),(30,'Removal of  Battery','R030'),(31,'General - Equipment','R032'),(32,'Service - 1000 km','R049'),(33,'Pre - Delivery','R050'),(34,'Service - 5000 km','R051'),(35,'Service - 10 000 km','R052'),(36,'Service - 20 000 km','R053'),(37,'Service - 7 500 km','R055'),(38,'Service - 15 000 km','R056'),(39,'Modification - Fuel Tanks','R061'),(40,'Modification - Canopies','R062'),(41,'Modification - Dog Kennels','R063'),(42,'Modification - Screens','R064'),(43,'Modification - Towbars','R065'),(44,'Damages','R071'),(45,'Accidents','R072'),(46,'Boarded Vehicles','R073'),(47,'Drive Shaft','R074'),(48,'Tow-In Services','R075'),(49,'Windscreen - Repairs','R076'),(50,'Windscreen - Replacement','R077'),(51,'Marking of GG Vehicle','R078'),(52,'Tyre Fitment / Repairs','R079'),(53,'Aircon Repairs / Re-Gas','R080'),(54,'Wheel Balancing','R081'),(55,'Cylinder Head','R082'),(56,'Replace - Battery','R083'),(57,'CV Joints','R084'),(58,'Valet / Car Wash','R085'),(59,'Wheel Balancing - Front','R086'),(60,'Wheel Balancing - Rear','R087'),(61,'Replace - Engine','R088'),(62,'Replace - Gearbox','R089'),(63,'Replace - Diff','R090');
/*!40000 ALTER TABLE `service_item_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_item_type` with 63 row(s)
--

--
-- Table structure for table `service_provider`
--

DROP TABLE IF EXISTS `service_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_provider` (
  `service_provider_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_provider_type` int(11) DEFAULT NULL,
  `service_provider_name` varchar(40) DEFAULT NULL,
  `service_provider_contact_email` varchar(40) DEFAULT NULL,
  `service_provider_contact_details` varchar(40) DEFAULT NULL,
  `service_provider_street_address` text,
  `service_provider_branch_code` varchar(40) DEFAULT NULL,
  `service_provider_branch` varchar(40) DEFAULT NULL,
  `service_provider_city` varchar(40) DEFAULT NULL,
  `service_provider_address_code` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`service_provider_id`),
  KEY `service_provider_type` (`service_provider_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_provider`
--

LOCK TABLES `service_provider` WRITE;
/*!40000 ALTER TABLE `service_provider` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `service_provider` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_provider` with 0 row(s)
--

--
-- Table structure for table `service_provider_type`
--

DROP TABLE IF EXISTS `service_provider_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_provider_type` (
  `service_provider_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_provider_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`service_provider_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_provider_type`
--

LOCK TABLES `service_provider_type` WRITE;
/*!40000 ALTER TABLE `service_provider_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `service_provider_type` VALUES (1,'Retail Bank');
/*!40000 ALTER TABLE `service_provider_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_provider_type` with 1 row(s)
--

--
-- Table structure for table `service_schedule`
--

DROP TABLE IF EXISTS `service_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_schedule` (
  `service_schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `breakdown_of_vehicle` varchar(40) DEFAULT NULL,
  `service_item_type` int(11) DEFAULT NULL,
  `service_category` int(11) DEFAULT NULL,
  `merchant_name` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `engine_number` int(6) DEFAULT NULL,
  `chassis_number` int(6) DEFAULT NULL,
  `dealer_name` int(11) DEFAULT NULL,
  `model_of_vehicle` int(6) DEFAULT NULL,
  `year_model_of_vehicle` int(6) DEFAULT NULL,
  `type_of_vehicle` int(6) DEFAULT NULL,
  `application_status` int(6) DEFAULT NULL,
  `barcode_number` int(6) DEFAULT NULL,
  `department` int(6) DEFAULT NULL,
  `service_item` text,
  `date_of_service` datetime DEFAULT NULL,
  `upload_quotation` varchar(40) DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `date_of_next_service` date DEFAULT NULL,
  `repeat_service_schedule_every_km` text,
  `comments` longtext,
  `upload_invoice` varchar(40) DEFAULT NULL,
  `receptionist` int(11) DEFAULT NULL,
  `receptionist_contact_email` int(11) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  `workshop_address` text,
  `technician` varchar(40) DEFAULT NULL,
  `work_order_id` int(11) DEFAULT NULL,
  `work_order_status` varchar(40) DEFAULT NULL,
  `job_card_number` int(11) DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `work_allocation_reference_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`service_schedule_id`),
  KEY `service_item_type` (`service_item_type`),
  KEY `service_category` (`service_category`),
  KEY `merchant_name` (`merchant_name`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `dealer_name` (`dealer_name`),
  KEY `closing_km` (`closing_km`),
  KEY `receptionist` (`receptionist`),
  KEY `workshop_name` (`workshop_name`),
  KEY `work_allocation_reference_number` (`work_allocation_reference_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_schedule`
--

LOCK TABLES `service_schedule` WRITE;
/*!40000 ALTER TABLE `service_schedule` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `service_schedule` VALUES (1,'No',45,5,1,1,1,1,3,1,1,1,1,1,1,NULL,'2020-01-10 00:00:00',NULL,1,'2020-09-30','15500','<br>',NULL,1,1,22,'<br>',NULL,NULL,'Pending',1,'2020-03-01','2020-03-01',NULL);
/*!40000 ALTER TABLE `service_schedule` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_schedule` with 1 row(s)
--

--
-- Table structure for table `service_type`
--

DROP TABLE IF EXISTS `service_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_type` (
  `service_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_item_type` int(11) DEFAULT NULL,
  `service_category` int(11) DEFAULT NULL,
  `service_item` varchar(40) DEFAULT NULL,
  `frequency_time_number` varchar(40) DEFAULT NULL,
  `frequency_time` varchar(40) DEFAULT NULL,
  `frequency_odometer` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`service_type_id`),
  KEY `service_item_type` (`service_item_type`),
  KEY `service_category` (`service_category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_type`
--

LOCK TABLES `service_type` WRITE;
/*!40000 ALTER TABLE `service_type` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `service_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `service_type` with 0 row(s)
--

--
-- Table structure for table `transmission`
--

DROP TABLE IF EXISTS `transmission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transmission` (
  `transmission_id` int(11) NOT NULL AUTO_INCREMENT,
  `transmission` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`transmission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transmission`
--

LOCK TABLES `transmission` WRITE;
/*!40000 ALTER TABLE `transmission` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `transmission` VALUES (1,'Automatic'),(2,'Electric'),(3,'Manual');
/*!40000 ALTER TABLE `transmission` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `transmission` with 3 row(s)
--

--
-- Table structure for table `tyre_log_sheet`
--

DROP TABLE IF EXISTS `tyre_log_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tyre_log_sheet` (
  `tyre_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `tyre_position` varchar(40) DEFAULT NULL,
  `tyre_tread_condition` varchar(40) DEFAULT NULL,
  `tyre_brand` varchar(40) DEFAULT NULL,
  `tyre_model` varchar(40) DEFAULT NULL,
  `tyre_size` varchar(40) DEFAULT NULL,
  `tyre_pressure` varchar(40) DEFAULT NULL,
  `action` text,
  `warranty` varchar(40) DEFAULT NULL,
  `documents` varchar(225) DEFAULT NULL,
  `tyre_tread` varchar(40) DEFAULT NULL,
  `tyre_maximum_wear` varchar(40) DEFAULT NULL,
  `inspection_date` date DEFAULT '0000-00-00',
  `tyre_inspection_done_by` varchar(40) DEFAULT NULL,
  `tyre_inspection_report` varchar(40) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `opening_km` varchar(15) NOT NULL,
  `closing_km` varchar(15) NOT NULL,
  `total_km` varchar(15) DEFAULT NULL,
  `comments` text,
  `tyres_cause_of_accident` varchar(40) DEFAULT NULL,
  `accident_report` varchar(40) DEFAULT NULL,
  `claims_report` varchar(40) DEFAULT NULL,
  `insurance_claims_report` varchar(40) DEFAULT NULL,
  `reminder_maximum_wear` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`tyre_log_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tyre_log_sheet`
--

LOCK TABLES `tyre_log_sheet` WRITE;
/*!40000 ALTER TABLE `tyre_log_sheet` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `tyre_log_sheet` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tyre_log_sheet` with 0 row(s)
--

--
-- Table structure for table `vehicle_colour`
--

DROP TABLE IF EXISTS `vehicle_colour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_colour` (
  `vehicle_colour_id` int(11) NOT NULL AUTO_INCREMENT,
  `colour_of_vehicle` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`vehicle_colour_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_colour`
--

LOCK TABLES `vehicle_colour` WRITE;
/*!40000 ALTER TABLE `vehicle_colour` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `vehicle_colour` VALUES (1,'Beige'),(2,'Black'),(3,'Blue'),(4,'Brown'),(5,'Burgundy'),(6,'Champaigne'),(7,'Charcoal'),(8,'Cream'),(9,'Gold'),(10,'Green'),(11,'Grey'),(12,'Maroon'),(13,'Off White'),(14,'Orange'),(15,'Purple'),(16,'Red'),(17,'Silver'),(18,'Tan'),(19,'Teal'),(20,'Titanium'),(21,'Turquoise'),(22,'White'),(23,'Yellow'),(24,'Pearl White'),(25,'Pearl Grey'),(26,'Pearl Green'),(27,'Pearl Blue'),(28,'Pearl Black');
/*!40000 ALTER TABLE `vehicle_colour` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vehicle_colour` with 28 row(s)
--

--
-- Table structure for table `vehicle_daily_check_list`
--

DROP TABLE IF EXISTS `vehicle_daily_check_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_daily_check_list` (
  `vehicle_daily_check_list_id` int(11) NOT NULL AUTO_INCREMENT,
  `inspection_certification_number` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `make_of_vehicle` int(6) DEFAULT NULL,
  `closing_km` int(11) NOT NULL,
  `dashboard` varchar(40) DEFAULT NULL,
  `seats` varchar(40) DEFAULT NULL,
  `carpets` varchar(40) DEFAULT NULL,
  `wipers` varchar(40) DEFAULT NULL,
  `head_lights` varchar(40) DEFAULT NULL,
  `tail_lights` varchar(40) DEFAULT NULL,
  `brake_lights` varchar(40) DEFAULT NULL,
  `indicators` varchar(40) DEFAULT NULL,
  `windscreen` varchar(40) DEFAULT NULL,
  `windows` varchar(40) DEFAULT NULL,
  `mirrors` varchar(40) DEFAULT NULL,
  `wheels` varchar(40) DEFAULT NULL,
  `hubcaps` varchar(40) DEFAULT NULL,
  `sparewheel` varchar(40) DEFAULT NULL,
  `tools` varchar(40) DEFAULT NULL,
  `engine_oil` varchar(40) DEFAULT NULL,
  `power_steering_oil` varchar(40) DEFAULT NULL,
  `gearbox_oil` varchar(40) DEFAULT NULL,
  `coolant` varchar(40) DEFAULT NULL,
  `brake_oil` varchar(40) DEFAULT NULL,
  `battery` varchar(40) DEFAULT NULL,
  `brakes_front` varchar(40) DEFAULT NULL,
  `brakes_rear` varchar(40) DEFAULT NULL,
  `fuel_level` varchar(40) DEFAULT NULL,
  `vehicle_fluid_leaks` varchar(40) DEFAULT NULL,
  `note` text,
  `document_checklist_report` varchar(40) DEFAULT NULL,
  `next_inspection_date` date DEFAULT NULL,
  `drivers_surname` int(11) DEFAULT NULL,
  `drivers_persal_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`vehicle_daily_check_list_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `closing_km` (`closing_km`),
  KEY `drivers_surname` (`drivers_surname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_daily_check_list`
--

LOCK TABLES `vehicle_daily_check_list` WRITE;
/*!40000 ALTER TABLE `vehicle_daily_check_list` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `vehicle_daily_check_list` VALUES (1,'LDoTaCS2019/09/11/453',1,1,1,'Ok',NULL,NULL,'Ok','Ok',NULL,NULL,NULL,'Ok','Ok','Ok',NULL,NULL,NULL,NULL,NULL,'Ok','Ok','Ok','Ok','Ok',NULL,'Ok','Ok','Ok','<br>','C5-Annex.pdf','2019-12-17',1,1);
/*!40000 ALTER TABLE `vehicle_daily_check_list` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vehicle_daily_check_list` with 1 row(s)
--

--
-- Table structure for table `vehicle_handing_over_checklist`
--

DROP TABLE IF EXISTS `vehicle_handing_over_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_handing_over_checklist` (
  `vehicle_handing_over_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(40) DEFAULT NULL,
  `company_address` text,
  `company_contact_details` varchar(40) DEFAULT NULL,
  `reason_for_handling_over` text,
  `name_of_department` varchar(40) DEFAULT NULL,
  `name_of_component` varchar(40) DEFAULT NULL,
  `transport_officer_name_and_surname` varchar(40) DEFAULT NULL,
  `transport_officer_contact_details` varchar(40) DEFAULT NULL,
  `job_pre_authorization_number` varchar(40) DEFAULT NULL,
  `authorization_number` int(11) DEFAULT NULL,
  `authorization_date` date DEFAULT '0000-00-00',
  `closing_km` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `model_of_vehicle` int(11) DEFAULT NULL,
  `radio_dvd_combination` varchar(40) DEFAULT NULL,
  `number_of_keys_handling_over` varchar(40) DEFAULT NULL,
  `jack_with_handle` varchar(40) DEFAULT NULL,
  `tyre_spare` varchar(40) DEFAULT NULL,
  `tyre_spare_condition` varchar(40) DEFAULT NULL,
  `wheel_spanner` varchar(40) DEFAULT NULL,
  `wheel_cups` text,
  `tri_angles` varchar(40) DEFAULT NULL,
  `mats` text,
  `other` text,
  `number_of_keys` varchar(40) DEFAULT NULL,
  `tyre_r_f` varchar(40) DEFAULT NULL,
  `tyre_r_f_1` varchar(40) DEFAULT NULL,
  `tyre_r_f_1_1` varchar(40) DEFAULT NULL,
  `tyre_r_r` varchar(40) DEFAULT NULL,
  `tyre_r_r_1` varchar(40) DEFAULT NULL,
  `tyre_r_r_1_1` varchar(40) DEFAULT NULL,
  `tyre_l_f` varchar(40) DEFAULT NULL,
  `tyre_l_f_1` varchar(40) DEFAULT NULL,
  `tyre_l_f_1_1` varchar(40) DEFAULT NULL,
  `tyer_l_r` varchar(40) DEFAULT NULL,
  `tyer_l_r_1` varchar(40) DEFAULT NULL,
  `tyre_l_r_1_1` varchar(40) DEFAULT NULL,
  `driver_name_and_surname` int(11) DEFAULT NULL,
  `driver_persal_number` int(11) DEFAULT NULL,
  `driver_signature` varchar(40) DEFAULT NULL,
  `date_checked_in` datetime DEFAULT '2020-01-01 00:00:00',
  `testing_officer_name_and_surname` varchar(40) DEFAULT NULL,
  `testing_officer_signature` varchar(40) DEFAULT NULL,
  `fuel_gauge_amount` varchar(40) DEFAULT NULL,
  `vehicle_marks_8` varchar(40) DEFAULT NULL,
  `remarks` text,
  `vehicle_marks_1` varchar(40) DEFAULT NULL,
  `vehicle_marks_2` varchar(40) DEFAULT NULL,
  `vehicle_marks_3` varchar(40) DEFAULT NULL,
  `vehicle_marks_4` varchar(40) DEFAULT NULL,
  `vehicle_marks_5` varchar(40) DEFAULT NULL,
  `vehicle_marks_6` varchar(40) DEFAULT NULL,
  `vehicle_marks_7` varchar(40) DEFAULT NULL,
  `vehicle_handing_over_ckecklist` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`vehicle_handing_over_id`),
  KEY `authorization_number` (`authorization_number`),
  KEY `closing_km` (`closing_km`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `driver_name_and_surname` (`driver_name_and_surname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_handing_over_checklist`
--

LOCK TABLES `vehicle_handing_over_checklist` WRITE;
/*!40000 ALTER TABLE `vehicle_handing_over_checklist` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `vehicle_handing_over_checklist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vehicle_handing_over_checklist` with 0 row(s)
--

--
-- Table structure for table `vehicle_history`
--

DROP TABLE IF EXISTS `vehicle_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `engine_number` int(6) DEFAULT NULL,
  `purchased_price` int(6) DEFAULT NULL,
  `old_registration_number` int(6) DEFAULT NULL,
  `new_vehicle_registration_number` varchar(25) DEFAULT NULL,
  `date_of_vehicle_transfer` date DEFAULT NULL,
  `comments` text,
  `renewal_of_license` int(6) DEFAULT NULL,
  `date_of_service` int(11) DEFAULT NULL,
  `date_of_next_service` int(11) DEFAULT NULL,
  `purchased_order_number` int(11) DEFAULT NULL,
  `claim_code` int(11) DEFAULT NULL,
  `tyre_inspection_report` int(11) DEFAULT NULL,
  `inspection_certification_number` int(11) DEFAULT NULL,
  `document_checklist_report` int(11) DEFAULT NULL,
  `next_inspection_date` int(11) DEFAULT '1',
  `breakdown_of_vehicle` varchar(40) DEFAULT NULL,
  `date_of_vehicle_breakdown` date DEFAULT NULL,
  `description_of_vehicle_breakdown` text,
  `closing_km` int(11) NOT NULL,
  `date_of_vehicle_reactivation` datetime DEFAULT NULL,
  `total_cost` int(11) DEFAULT '0',
  PRIMARY KEY (`history_id`),
  UNIQUE KEY `new_vehicle_registration_number_unique` (`new_vehicle_registration_number`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `date_of_service` (`date_of_service`),
  KEY `purchased_order_number` (`purchased_order_number`),
  KEY `claim_code` (`claim_code`),
  KEY `tyre_inspection_report` (`tyre_inspection_report`),
  KEY `inspection_certification_number` (`inspection_certification_number`),
  KEY `document_checklist_report` (`document_checklist_report`),
  KEY `total_cost` (`total_cost`),
  KEY `closing_km` (`closing_km`),
  KEY `next_inspection_date` (`next_inspection_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_history`
--

LOCK TABLES `vehicle_history` WRITE;
/*!40000 ALTER TABLE `vehicle_history` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `vehicle_history` VALUES (1,1,1,1,1,NULL,NULL,'<br>',1,1,1,1,1,NULL,NULL,NULL,1,NULL,NULL,'<br>',1,'2020-03-11 17:22:00',0);
/*!40000 ALTER TABLE `vehicle_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vehicle_history` with 1 row(s)
--

--
-- Table structure for table `vehicle_payments`
--

DROP TABLE IF EXISTS `vehicle_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_payments` (
  `vehicle_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_registration_number` int(6) DEFAULT NULL,
  `engine_number` int(6) DEFAULT NULL,
  `chassis_number` int(6) DEFAULT NULL,
  `make_of_vehicle` int(6) DEFAULT NULL,
  `model_of_vehicle` int(6) DEFAULT NULL,
  `year_model_of_vehicle` int(6) DEFAULT NULL,
  `type_of_vehicle` int(6) DEFAULT NULL,
  `application_status` int(6) DEFAULT NULL,
  `barcode_number` int(6) DEFAULT NULL,
  `purchase_price` decimal(10,2) DEFAULT NULL,
  `depreciation_value` decimal(10,2) DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `department` int(6) DEFAULT NULL,
  `acquisition_reference` varchar(40) DEFAULT NULL,
  `date_of_acquisition` date DEFAULT NULL,
  `odometer_at_acquisition` varchar(40) DEFAULT NULL,
  `merchant_name` int(11) DEFAULT NULL,
  `value_at_acquisition` decimal(10,2) DEFAULT NULL,
  `term` varchar(40) DEFAULT NULL,
  `month_end` date DEFAULT NULL,
  `installment_per_month` decimal(10,2) DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `payment_frequency` varchar(40) DEFAULT NULL,
  `interest_rate` int(11) DEFAULT NULL,
  `payment_reference` varchar(40) DEFAULT NULL,
  `paid_so_far` decimal(10,2) DEFAULT NULL,
  `remaining_balance` decimal(10,2) DEFAULT NULL,
  `depreciation_since_purchase` varchar(40) DEFAULT NULL,
  `actual_resale_value` varchar(40) DEFAULT NULL,
  `warranty_expires_on` date DEFAULT NULL,
  `comments` longtext,
  `documents` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`vehicle_payment_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `closing_km` (`closing_km`),
  KEY `merchant_name` (`merchant_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_payments`
--

LOCK TABLES `vehicle_payments` WRITE;
/*!40000 ALTER TABLE `vehicle_payments` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `vehicle_payments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vehicle_payments` with 0 row(s)
--

--
-- Table structure for table `vehicle_return_check_list`
--

DROP TABLE IF EXISTS `vehicle_return_check_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_return_check_list` (
  `vehicle_return_check_list_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_return_date` date DEFAULT '0000-00-00',
  `job_card_number` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `model_of_vehicle` int(11) DEFAULT NULL,
  `closing_km` int(11) DEFAULT NULL,
  `radio_dvd_combination` varchar(40) DEFAULT NULL,
  `number_of_keys_handling_over` varchar(40) DEFAULT NULL,
  `jack_with_handle` varchar(40) DEFAULT NULL,
  `tyre_spare` varchar(40) DEFAULT NULL,
  `tyre_spare_condition` varchar(40) DEFAULT NULL,
  `wheel_spanner` varchar(40) DEFAULT NULL,
  `wheel_cups` text,
  `tri_angles` varchar(40) DEFAULT NULL,
  `other` text,
  `number_of_keys` varchar(40) DEFAULT NULL,
  `vehicle_washed` varchar(40) DEFAULT NULL,
  `tyre_r_f` varchar(40) DEFAULT NULL,
  `tyre_r_f_1` varchar(40) DEFAULT NULL,
  `tyre_r_f_1_1` varchar(40) DEFAULT NULL,
  `tyre_r_r` varchar(40) DEFAULT NULL,
  `tyre_r_r_1` varchar(40) DEFAULT NULL,
  `tyre_r_r_1_1` varchar(40) DEFAULT NULL,
  `tyre_l_f` varchar(40) DEFAULT NULL,
  `tyre_l_f_1` varchar(40) DEFAULT NULL,
  `tyre_l_f_1_1` varchar(40) DEFAULT NULL,
  `tyer_l_r` varchar(40) DEFAULT NULL,
  `tyer_l_r_1` varchar(40) DEFAULT NULL,
  `tyre_l_r_1_1` varchar(40) DEFAULT NULL,
  `fuel_gauge_amount` varchar(40) DEFAULT NULL,
  `driver_name_and_surname` int(11) DEFAULT NULL,
  `driver_persal_number` int(11) DEFAULT NULL,
  `driver_signature` varchar(40) DEFAULT NULL,
  `vehicle_return_date_signed` datetime DEFAULT '2020-01-01 00:00:00',
  `testing_officer_name_and_surname` varchar(40) DEFAULT NULL,
  `testing_officer_signature` varchar(40) DEFAULT NULL,
  `vehicle_marks_1` varchar(40) DEFAULT NULL,
  `vehicle_marks_2` varchar(40) DEFAULT NULL,
  `vehicle_marks_3` varchar(40) DEFAULT NULL,
  `vehicle_marks_4` varchar(40) DEFAULT NULL,
  `vehicle_marks_5` varchar(40) DEFAULT NULL,
  `vehicle_marks_6` varchar(40) DEFAULT NULL,
  `vehicle_marks_7` varchar(40) DEFAULT NULL,
  `vehicle_marks_8` varchar(40) DEFAULT NULL,
  `remarks` text,
  `vehicle_return_list` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`vehicle_return_check_list_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `closing_km` (`closing_km`),
  KEY `driver_name_and_surname` (`driver_name_and_surname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_return_check_list`
--

LOCK TABLES `vehicle_return_check_list` WRITE;
/*!40000 ALTER TABLE `vehicle_return_check_list` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `vehicle_return_check_list` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vehicle_return_check_list` with 0 row(s)
--

--
-- Table structure for table `withdrawal_vehicle_from_operation`
--

DROP TABLE IF EXISTS `withdrawal_vehicle_from_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdrawal_vehicle_from_operation` (
  `withdrawal_id` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor_name_and_surname` varchar(40) DEFAULT NULL,
  `supervisor_contact_details` varchar(40) DEFAULT NULL,
  `supervisor_email_address` varchar(40) DEFAULT NULL,
  `supervisor_signature` varchar(40) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `purchased_price` int(11) DEFAULT '0',
  `date_of_service` int(11) DEFAULT NULL,
  `date_of_next_service` int(11) DEFAULT NULL,
  `renewal_of_license` int(11) DEFAULT NULL,
  `date_of_vehicle` varchar(40) DEFAULT NULL,
  `description_of_vehicle_breakdown` text,
  `tyre_inspection_report` varchar(40) DEFAULT NULL,
  `document_checklist_report` varchar(40) DEFAULT NULL,
  `compiled_technical_report` varchar(40) DEFAULT NULL,
  `district_officer_surname` varchar(40) DEFAULT NULL,
  `district_officer_persal_number` varchar(40) DEFAULT NULL,
  `district_officer_contacts` varchar(40) DEFAULT NULL,
  `district_officer_signature` varchar(40) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `district_officer_email_address` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`withdrawal_id`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `engine_number` (`engine_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `date_of_service` (`date_of_service`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawal_vehicle_from_operation`
--

LOCK TABLES `withdrawal_vehicle_from_operation` WRITE;
/*!40000 ALTER TABLE `withdrawal_vehicle_from_operation` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `withdrawal_vehicle_from_operation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `withdrawal_vehicle_from_operation` with 0 row(s)
--

--
-- Table structure for table `work_allocation`
--

DROP TABLE IF EXISTS `work_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_allocation` (
  `work_allocation_id` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor_name_and_surname` varchar(40) DEFAULT NULL,
  `supervisor_contact_details` varchar(40) DEFAULT NULL,
  `supervisor_email_address` int(11) DEFAULT NULL,
  `supervisor_signature` varchar(40) DEFAULT NULL,
  `economical_repair` int(11) DEFAULT NULL,
  `uneconomical_repair` int(11) DEFAULT NULL,
  `vehicle_registration_number` int(11) DEFAULT NULL,
  `engine_number` int(11) DEFAULT NULL,
  `make_of_vehicle` int(11) DEFAULT NULL,
  `date_captured` datetime DEFAULT NULL,
  `work_allocation_reference_number` varchar(40) DEFAULT NULL,
  `workshop_name` int(11) DEFAULT NULL,
  PRIMARY KEY (`work_allocation_id`),
  UNIQUE KEY `uneconomical_repair_unique` (`uneconomical_repair`),
  KEY `vehicle_registration_number` (`vehicle_registration_number`),
  KEY `make_of_vehicle` (`make_of_vehicle`),
  KEY `workshop_name` (`workshop_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_allocation`
--

LOCK TABLES `work_allocation` WRITE;
/*!40000 ALTER TABLE `work_allocation` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `work_allocation` VALUES (1,NULL,NULL,NULL,NULL,0,NULL,1,1,1,'2020-03-12 17:24:42','LDTCS0312-Dilokong',17);
/*!40000 ALTER TABLE `work_allocation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `work_allocation` with 1 row(s)
--

--
-- Table structure for table `year_model`
--

DROP TABLE IF EXISTS `year_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `year_model` (
  `year_model_id` int(11) NOT NULL AUTO_INCREMENT,
  `year_model_specification` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`year_model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `year_model`
--

LOCK TABLES `year_model` WRITE;
/*!40000 ALTER TABLE `year_model` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `year_model` VALUES (1,'2007'),(2,'2008'),(3,'2009'),(4,'2010'),(5,'2011'),(6,'2012'),(7,'2013'),(8,'2014'),(9,'2015'),(10,'2016'),(11,'2017'),(12,'2018'),(13,'2019'),(14,'2020'),(15,'2021'),(16,'2022'),(17,'2023'),(18,'2024'),(19,'2025');
/*!40000 ALTER TABLE `year_model` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `year_model` with 19 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Thu, 19 Mar 2020 12:59:12 +0200
